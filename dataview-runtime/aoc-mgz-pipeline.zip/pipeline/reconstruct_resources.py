#!/usr/bin/env python3
"""Deterministic best-effort AoE II resource reconstruction.

This is an event-sourced inference model, not an exact engine simulation. It
uses only replay evidence at or before each timestamp in the forward pass,
keeps aggregate checkpoint residuals visible, and limits map-resource
corrections by plausible node/farm capacity.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
import statistics
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


DEFAULT_VIEWER_DIR = Path(".")
DEFAULT_GAME = DEFAULT_VIEWER_DIR / "game.json"
DEFAULT_LIFETIMES = DEFAULT_VIEWER_DIR / "lifetimes.json"
DEFAULT_ECONOMY = DEFAULT_VIEWER_DIR / "economy.json"
DEFAULT_REFERENCE = Path("/tmp/aoe2techtree-data.json")
DEFAULT_OUTPUT = DEFAULT_VIEWER_DIR / "resource_estimates.json"

SCHEMA = "aoe2-resource-reconstruction/v1"
RESOURCE_KEYS = ("Food", "Wood", "Gold", "Stone")
STARTING_STOCKPILE = {"Food": 200.0, "Wood": 200.0, "Gold": 100.0, "Stone": 200.0}
STARTING_TOTAL = sum(STARTING_STOCKPILE.values())

RESOURCE_CAPACITY = {
    "Gold Mine": 800.0,
    "Stone Mine": 350.0,
    "Fruit Bush": 125.0,
    "Forage Bush": 125.0,
    "Bush B": 125.0,
    "Sheep": 100.0,
    "Wild Boar": 340.0,
    "Ibex": 140.0,
}
TREE_CAPACITY = 100.0
FARM_FOOD_CAPACITY = {
    "none": 175.0,
    "Horse Collar": 250.0,
    "Heavy Plow": 375.0,
    "Crop Rotation": 550.0,
}
FARM_WOOD_COST = 60.0

BASE_GATHER_RATES = {
    "Food": 0.31,
    "Wood": 0.33,
    "Gold": 0.36,
    "Stone": 0.32,
}
SUBTYPE_RATE_MULTIPLIERS = {
    "berries": 0.95,
    "herdable": 0.95,
    "wild": 1.18,
    "farm": 0.96,
    "tree": 0.9,
    "mine": 1.0,
    "unknown": 0.7,
}

MARKET_BUY_START = 130
MARKET_SELL_START = 70
MARKET_STEP = 3
MARKET_MIN_SELL = 14


def seconds(value: str | int | float) -> float:
    """Convert the parser's H:MM:SS.ffffff clock to seconds."""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        result = float(value)
    elif isinstance(value, str):
        hours, minutes, secs = value.split(":")
        result = int(hours) * 3600 + int(minutes) * 60 + float(secs)
    else:
        raise TypeError(f"invalid timestamp: {value!r}")
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"invalid nonnegative timestamp: {value!r}")
    return round(result, 3)


def duration_label(value: float) -> str:
    millis = int(round(value * 1000))
    hours = millis // 3_600_000
    minutes = millis % 3_600_000 // 60_000
    secs = millis % 60_000 // 1000
    rem = millis % 1000
    return f"{hours}:{minutes:02d}:{secs:02d}.{rem:03d}"


def clean_number(value: float | int, digits: int = 3) -> float | int:
    number = round(float(value), digits)
    if abs(number) < 10 ** -digits:
        number = 0.0
    return int(number) if float(number).is_integer() else number


def clean_resources(values: dict[str, float], digits: int = 3) -> dict[str, float | int]:
    return {resource: clean_number(values.get(resource, 0.0), digits) for resource in RESOURCE_KEYS}


def finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numeric_position(value: Any) -> dict[str, float] | None:
    if not isinstance(value, dict):
        return None
    x, y = value.get("x"), value.get("y")
    if not finite_number(x) or not finite_number(y):
        return None
    return {"x": round(float(x), 4), "y": round(float(y), 4)}


def position_key(position: dict[str, float] | None) -> tuple[float, float] | None:
    if position is None:
        return None
    return (round(float(position["x"]), 2), round(float(position["y"]), 2))


def placement_bounds(row: dict[str, Any]) -> tuple[float, float, float, float] | None:
    if row.get("end_position") is not None:
        return None
    position = numeric_position(row.get("position"))
    if position is None:
        return None
    footprint = row.get("footprint") if isinstance(row.get("footprint"), dict) else {}
    width = footprint.get("tile_width", 3)
    height = footprint.get("tile_height", 3)
    if not finite_number(width) or not finite_number(height) or float(width) <= 0 or float(height) <= 0:
        return None
    half_width = float(width) / 2
    half_height = float(height) / 2
    return (
        position["x"] - half_width,
        position["x"] + half_width,
        position["y"] - half_height,
        position["y"] + half_height,
    )


def position_in_bounds(position: dict[str, float] | None, bounds: tuple[float, float, float, float] | None) -> bool:
    if position is None or bounds is None:
        return False
    left, right, top, bottom = bounds
    return left < position["x"] < right and top < position["y"] < bottom


def resource_tile_overlaps_bounds(
    position: dict[str, float] | None,
    bounds: tuple[float, float, float, float] | None,
) -> bool:
    """Return whether a one-tile resource footprint overlaps a building."""
    if position is None or bounds is None:
        return False
    left, right, top, bottom = bounds
    return (
        position["x"] + 0.5 > left
        and position["x"] - 0.5 < right
        and position["y"] + 0.5 > top
        and position["y"] - 0.5 < bottom
    )


def object_ids(payload: Any) -> tuple[int, ...]:
    if not isinstance(payload, dict):
        return ()
    values = payload.get("object_ids", [])
    if not isinstance(values, list):
        return ()
    return tuple(value for value in values if isinstance(value, int) and value > 0)


def sorted_unique(values: Iterable[Any]) -> list[Any]:
    return sorted(set(values), key=lambda item: (str(type(item)), item))


def resource_family(name: str | None) -> tuple[str | None, str]:
    if not isinstance(name, str) or not name.strip():
        return None, "unknown"
    lowered = name.casefold()
    if "gold" in lowered or lowered == "relic":
        return "Gold", "relic" if lowered == "relic" else "mine"
    if "stone" in lowered:
        return "Stone", "mine"
    if "tree" in lowered or "forest" in lowered:
        return "Wood", "tree"
    if "farm" in lowered:
        return "Food", "farm"
    if any(token in lowered for token in ("bush", "fruit", "forage")):
        return "Food", "berries"
    if any(token in lowered for token in ("sheep", "goat", "cow", "turkey")):
        return "Food", "herdable"
    if any(token in lowered for token in ("boar", "ibex", "deer", "zebra", "ostrich", "rhino", "elephant")):
        return "Food", "wild"
    return None, "unknown"


def resource_name_from_target(row: dict[str, Any], catalog: dict[int, "ObjectInfo"]) -> str | None:
    param = row.get("param")
    if isinstance(param, str) and param.strip():
        return param.strip()
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    target_id = payload.get("target_id")
    if isinstance(target_id, int) and target_id in catalog:
        return catalog[target_id].name
    return None


def event_position(row: dict[str, Any]) -> dict[str, float] | None:
    position = numeric_position(row.get("position"))
    if position is not None:
        return position
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    return numeric_position({"x": payload.get("x"), "y": payload.get("y")})


@dataclass(frozen=True)
class ObjectInfo:
    instance_id: int
    name: str | None = None
    owner: int | None = None
    position: dict[str, float] | None = None
    class_id: int | None = None
    object_id: int | None = None
    source: str = "unknown"


@dataclass
class ResourceNode:
    node_id: int
    name: str
    family: str
    subtype: str
    position: dict[str, float]
    starting_capacity: float
    remaining: float
    cluster_id: str | None = None
    touched: bool = False
    depleted_time: float | None = None
    extraction_by_player: dict[int, float] = field(default_factory=lambda: defaultdict(float))

    def consume(self, amount: float, player: int, time: float) -> float:
        if amount <= 0:
            return 0.0
        taken = min(self.remaining, amount)
        if taken > 0:
            self.remaining = max(0.0, self.remaining - taken)
            self.touched = True
            self.extraction_by_player[player] += taken
            if self.remaining <= 0.0001 and self.depleted_time is None:
                self.depleted_time = round(time, 3)
        return taken


@dataclass
class Generation:
    generation_id: str
    seed_time: float
    source: str
    capacity: float
    remaining: float
    wood_cost: float
    active_tech: str
    evidence: str
    confidence: str
    depleted_time: float | None = None
    disappearance_time: float | None = None
    farmer_ids: list[Any] = field(default_factory=list)


@dataclass
class FarmPlot:
    plot_id: str
    player: int
    position: dict[str, float]
    auto_reseed_state: str = "unknown"
    generations: list[Generation] = field(default_factory=list)
    assigned_workers: set[Any] = field(default_factory=set)
    abandonment: list[dict[str, Any]] = field(default_factory=list)
    inactive_since: float | None = None

    def active_generation(self, time: float) -> Generation | None:
        active = None
        for generation in self.generations:
            if generation.seed_time <= time and generation.disappearance_time is None:
                active = generation
        if active and active.remaining > 0:
            return active
        return None


@dataclass(frozen=True)
class Assignment:
    worker_id: Any
    player: int
    state: str
    family: str | None = None
    subtype: str = "unknown"
    target_id: int | None = None
    farm_plot_id: str | None = None
    position: dict[str, float] | None = None
    confidence: str = "observed"
    reason: str = ""


@dataclass
class RuleTables:
    units: dict[str, Any]
    buildings: dict[str, Any]
    techs: dict[str, Any]
    unit_upgrades: dict[str, Any]

    @classmethod
    def from_reference(cls, reference: dict[str, Any]) -> "RuleTables":
        data = reference.get("data")
        if not isinstance(data, dict):
            raise ValueError("reference JSON does not contain data")
        return cls(
            units=data.get("Unit", {}) if isinstance(data.get("Unit"), dict) else {},
            buildings=data.get("Building", {}) if isinstance(data.get("Building"), dict) else {},
            techs=data.get("Tech", {}) if isinstance(data.get("Tech"), dict) else {},
            unit_upgrades=data.get("unit_upgrades", {}) if isinstance(data.get("unit_upgrades"), dict) else {},
        )

    def unit(self, unit_id: Any) -> dict[str, Any] | None:
        return self._entry(self.units, unit_id)

    def building(self, building_id: Any) -> dict[str, Any] | None:
        lookup_id = 49 if building_id == 490 else building_id
        return self._entry(self.buildings, lookup_id)

    def tech(self, tech_id: Any) -> dict[str, Any] | None:
        entry = self._entry(self.techs, tech_id)
        if entry is not None:
            return entry
        if isinstance(tech_id, int):
            matches = [
                value for value in self.unit_upgrades.values()
                if isinstance(value, dict) and value.get("ID") == tech_id
            ]
            if matches:
                matches.sort(key=lambda value: (str(value.get("internal_name", "")), json.dumps(value, sort_keys=True)))
                return matches[0]
        return None

    @staticmethod
    def _entry(table: dict[str, Any], entity_id: Any) -> dict[str, Any] | None:
        if not isinstance(entity_id, int):
            return None
        value = table.get(str(entity_id))
        return value if isinstance(value, dict) else None


@dataclass
class RawEvidence:
    players: list[dict[str, Any]]
    duration: float
    inputs: list[dict[str, Any]]
    checkpoints: list[dict[str, Any]]
    spending: list[dict[str, Any]]
    market: list[dict[str, Any]]
    cancellations: list[dict[str, Any]]
    building_placements: list[dict[str, Any]]
    unit_completions: list[dict[str, Any]]
    tech_starts: list[dict[str, Any]]
    tech_completions: list[dict[str, Any]]
    catalog: dict[int, ObjectInfo]
    counts: dict[str, int]
    deduplication: dict[str, Any]


def normalized_cost(raw: Any, multiplier: int | float = 1) -> dict[str, float]:
    if not isinstance(raw, dict) or not finite_number(multiplier) or float(multiplier) < 0:
        return {}
    result: dict[str, float] = {}
    for resource in RESOURCE_KEYS:
        value = raw.get(resource)
        if finite_number(value):
            total = float(value) * float(multiplier)
            if total > 0:
                result[resource] = round(total, 4)
    return result


def add_resources(target: dict[str, float], delta: dict[str, float], sign: float = 1.0) -> None:
    for resource in RESOURCE_KEYS:
        target[resource] = target.get(resource, 0.0) + sign * float(delta.get(resource, 0.0))


def total_resources(values: dict[str, float]) -> float:
    return sum(float(values.get(resource, 0.0)) for resource in RESOURCE_KEYS)


def semantic_identity(row: dict[str, Any]) -> tuple[Any, ...]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    kind = row.get("type")
    position = position_key(numeric_position(row.get("position")))
    end = None
    if kind == "Wall":
        end = position_key(numeric_position({"x": payload.get("x_end"), "y": payload.get("y_end")}))
    return (
        kind,
        row.get("player"),
        row.get("param"),
        payload.get("unit_id"),
        payload.get("building_id"),
        payload.get("technology_id"),
        payload.get("target_id"),
        payload.get("resource_id"),
        payload.get("amount"),
        object_ids(payload),
        position,
        end,
    )


def exact_identity(row: dict[str, Any]) -> tuple[Any, ...]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    return (
        row.get("timestamp"),
        row.get("type"),
        row.get("player"),
        row.get("param"),
        payload.get("sequence"),
        json.dumps(payload, sort_keys=True, separators=(",", ":")),
        json.dumps(row.get("position"), sort_keys=True, separators=(",", ":")),
    )


def sortable_identity_value(value: Any) -> tuple[Any, ...]:
    """Preserve normal ordering while making nullable mixed types comparable."""
    if value is None:
        return (0, "")
    if isinstance(value, bool):
        return (1, int(value))
    if isinstance(value, (int, float)):
        return (2, value)
    if isinstance(value, str):
        return (3, value)
    if isinstance(value, tuple):
        return (4, tuple(sortable_identity_value(item) for item in value))
    return (5, repr(value))


def exact_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
    """Return a deterministic sortable key for a possibly nullable identity."""
    return tuple(sortable_identity_value(value) for value in exact_identity(row))


def normalize_inputs(rows: Iterable[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Deduplicate parser echoes while preserving distinct rapid commands."""
    ordered = sorted(
        (row for row in rows if isinstance(row, dict) and "timestamp" in row),
        key=lambda row: (
            seconds(row["timestamp"]),
            exact_sort_key(row),
        ),
    )
    exact_seen: set[tuple[Any, ...]] = set()
    latest_semantic: dict[tuple[Any, ...], float] = {}
    kept: list[dict[str, Any]] = []
    removed = defaultdict(int)

    for row in ordered:
        exact = exact_identity(row)
        if exact in exact_seen:
            removed["exact_duplicate"] += 1
            continue
        exact_seen.add(exact)

        kind = row.get("type")
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        amount = payload.get("amount")
        key = semantic_identity(row)
        time = seconds(row["timestamp"])
        prior = latest_semantic.get(key)
        latest_semantic[key] = time

        collapse_echo = False
        if prior is not None and time - prior <= 1.0:
            if kind == "Queue":
                collapse_echo = isinstance(amount, int) and amount > 1
            elif kind in {"Research", "Reseed"}:
                collapse_echo = True
            elif kind in {"Build", "Wall"}:
                collapse_echo = position_key(numeric_position(row.get("position"))) is not None
            elif kind in {"Farm Autoqueue", "Fish Trap Autoqueue"}:
                collapse_echo = True
        if collapse_echo:
            removed[f"{kind}_near_echo"] += 1
            continue
        kept.append(row)

    return kept, {
        "input_rows": len(ordered),
        "normalized_rows": len(kept),
        "removed": {key: value for key, value in sorted(removed.items())},
        "policy": (
            "Exact duplicate rows are removed. Rapid one-click Queue inputs remain distinct; "
            "rapid repeated batch Queue, Research, Reseed, Build, Wall, and autoqueue rows with "
            "the same semantic identity are treated as parser echoes."
        ),
    }


def build_object_catalog(game: dict[str, Any], lifetimes: dict[str, Any]) -> dict[int, ObjectInfo]:
    catalog: dict[int, ObjectInfo] = {}

    def add_object(raw: dict[str, Any], source: str, owner: int | None = None) -> None:
        instance_id = raw.get("instance_id")
        if not isinstance(instance_id, int):
            return
        existing = catalog.get(instance_id)
        name = raw.get("name") if isinstance(raw.get("name"), str) else (existing.name if existing else None)
        position = numeric_position(raw.get("position") or raw.get("start_position")) or (existing.position if existing else None)
        object_owner = raw.get("owner") if isinstance(raw.get("owner"), int) else owner
        if object_owner is None and existing:
            object_owner = existing.owner
        class_id = raw.get("class_id") if isinstance(raw.get("class_id"), int) else (existing.class_id if existing else None)
        object_id = raw.get("object_id") if isinstance(raw.get("object_id"), int) else (existing.object_id if existing else None)
        catalog[instance_id] = ObjectInfo(instance_id, name, object_owner, position, class_id, object_id, source)

    match = game.get("match", {})
    for raw in match.get("gaia", []) if isinstance(match.get("gaia"), list) else []:
        if isinstance(raw, dict):
            add_object(raw, "game.match.gaia")
    for player in match.get("players", []) if isinstance(match.get("players"), list) else []:
        owner = player.get("number") if isinstance(player, dict) and isinstance(player.get("number"), int) else None
        objects = player.get("objects") if isinstance(player, dict) else []
        for raw in objects if isinstance(objects, list) else []:
            if isinstance(raw, dict):
                add_object(raw, "game.match.players.objects", owner)
    for raw in lifetimes.get("objects", []) if isinstance(lifetimes.get("objects"), list) else []:
        if isinstance(raw, dict):
            add_object(raw, "lifetimes.objects")
    return catalog


def is_worker(instance_id: Any, catalog: dict[int, ObjectInfo]) -> bool:
    if not isinstance(instance_id, int):
        return False
    info = catalog.get(instance_id)
    if info is None:
        return False
    return info.name == "Villager" or info.object_id in {83, 293}


def wall_multiplier(row: dict[str, Any]) -> int:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    position = numeric_position(row.get("position"))
    end = numeric_position({"x": payload.get("x_end"), "y": payload.get("y_end")})
    if position is None or end is None:
        return 0
    return int(max(abs(end["x"] - position["x"]), abs(end["y"] - position["y"]))) + 1


def extract_rule_events(inputs: list[dict[str, Any]], rules: RuleTables) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, int]]:
    spending: list[dict[str, Any]] = []
    unit_completions: list[dict[str, Any]] = []
    tech_starts: list[dict[str, Any]] = []
    tech_completions: list[dict[str, Any]] = []
    unresolved = defaultdict(int)
    producer_available: dict[tuple[int, Any], float] = defaultdict(float)

    queue_rows = [row for row in inputs if row.get("type") == "Queue"]
    for queue_index, row in enumerate(queue_rows):
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        time = seconds(row["timestamp"])
        player = row.get("player")
        amount = payload.get("amount")
        unit_id = payload.get("unit_id")
        name = payload.get("unit") or row.get("param")
        if not isinstance(player, int) or not isinstance(amount, int) or amount <= 0 or not isinstance(name, str):
            unresolved["Queue_invalid_payload"] += 1
            continue
        entry = rules.unit(unit_id)
        cost = normalized_cost(entry.get("Cost") if entry else None, amount)
        if cost:
            spending.append({
                "time": time,
                "player": player,
                "kind": "Queue",
                "name": name,
                "cost": cost,
                "income": {},
                "source": "input",
                "object_ids": list(object_ids(payload)),
                "confidence": "observed_command_cost_estimate",
            })
        else:
            unresolved["Queue_cost"] += 1
        train_time = entry.get("TrainTime") if entry else None
        if not finite_number(train_time):
            unresolved["Queue_train_time"] += 1
            continue
        producers: list[Any] = list(object_ids(payload)) or [f"unknown:{queue_index}"]
        for _ in range(amount):
            choices = []
            for producer in producers:
                start = max(time, producer_available[(player, producer)])
                choices.append((start + float(train_time), str(producer), producer))
            completion, _, producer = min(choices)
            producer_available[(player, producer)] = completion
            unit_completions.append({
                "time": round(completion, 3),
                "player": player,
                "name": name,
                "producer_id": producer if isinstance(producer, int) else None,
                "confidence": "queue_train_time_estimate",
            })

    for row in inputs:
        kind = row.get("type")
        if kind not in {"Build", "Reseed", "Wall"}:
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        time = seconds(row["timestamp"])
        player = row.get("player")
        name = payload.get("building") or row.get("param")
        if not isinstance(player, int) or not isinstance(name, str):
            unresolved[f"{kind}_invalid_payload"] += 1
            continue
        multiplier = wall_multiplier(row) if kind == "Wall" else 1
        entry = rules.building(payload.get("building_id"))
        cost = normalized_cost(entry.get("Cost") if entry else None, multiplier)
        if cost:
            spending.append({
                "time": time,
                "player": player,
                "kind": kind,
                "name": name,
                "cost": cost,
                "income": {},
                "source": "input",
                "object_ids": list(object_ids(payload)),
                "position": numeric_position(row.get("position")),
                "confidence": "observed_command_cost_estimate",
            })
        else:
            unresolved[f"{kind}_cost"] += 1

    for row in inputs:
        if row.get("type") != "Research":
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        time = seconds(row["timestamp"])
        player = row.get("player")
        name = payload.get("technology") or row.get("param")
        if not isinstance(player, int) or not isinstance(name, str):
            unresolved["Research_invalid_payload"] += 1
            continue
        entry = rules.tech(payload.get("technology_id"))
        cost = normalized_cost(entry.get("Cost") if entry else None)
        if cost:
            spending.append({
                "time": time,
                "player": player,
                "kind": "Research",
                "name": name,
                "cost": cost,
                "income": {},
                "source": "input",
                "object_ids": list(object_ids(payload)),
                "confidence": "observed_command_cost_estimate",
            })
        else:
            unresolved["Research_cost"] += 1
        research_time = entry.get("ResearchTime") if entry else None
        tech_starts.append({
            "time": time,
            "player": player,
            "name": name,
            "technology_id": payload.get("technology_id"),
            "producer_ids": list(object_ids(payload)),
            "research_time": clean_number(research_time) if finite_number(research_time) else None,
        })
        if finite_number(research_time):
            tech_completions.append({
                "time": round(time + float(research_time), 3),
                "player": player,
                "name": name,
                "technology_id": payload.get("technology_id"),
                "confidence": "research_time_estimate",
            })
        else:
            unresolved["Research_time"] += 1

    def sort_key(event: dict[str, Any]) -> tuple[Any, ...]:
        return (event["time"], event.get("player", -1), event.get("kind", ""), event.get("name", ""))

    spending.sort(key=sort_key)
    unit_completions.sort(key=sort_key)
    tech_starts.sort(key=sort_key)
    tech_completions.sort(key=sort_key)
    return spending, unit_completions, tech_starts, tech_completions, unresolved


def extract_market_events(inputs: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, int]]:
    market_rows = sorted(
        [row for row in inputs if row.get("type") in {"Buy", "Sell"}],
        key=lambda row: (seconds(row["timestamp"]), exact_identity(row)),
    )
    prices = {
        "Food": {"buy": MARKET_BUY_START, "sell": MARKET_SELL_START},
        "Wood": {"buy": MARKET_BUY_START, "sell": MARKET_SELL_START},
        "Stone": {"buy": MARKET_BUY_START, "sell": MARKET_SELL_START},
    }
    market: list[dict[str, Any]] = []
    unresolved = defaultdict(int)
    for row in market_rows:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        player = row.get("player")
        resource = payload.get("resource")
        amount = payload.get("amount")
        if not isinstance(player, int) or resource not in prices or not finite_number(amount):
            unresolved["Market_invalid_payload"] += 1
            continue
        lots = int(round(float(amount) / 100.0))
        if lots <= 0 or abs(lots * 100 - float(amount)) > 0.001:
            unresolved["Market_nonstandard_amount"] += 1
            continue
        cost = {key: 0.0 for key in RESOURCE_KEYS}
        income = {key: 0.0 for key in RESOURCE_KEYS}
        price_path: list[int] = []
        if row.get("type") == "Buy":
            for _ in range(lots):
                price = prices[resource]["buy"]
                price_path.append(price)
                cost["Gold"] += price
                income[resource] += 100.0
                prices[resource]["buy"] += MARKET_STEP
                prices[resource]["sell"] += MARKET_STEP
        else:
            for _ in range(lots):
                price = prices[resource]["sell"]
                price_path.append(price)
                cost[resource] += 100.0
                income["Gold"] += price
                prices[resource]["sell"] = max(MARKET_MIN_SELL, prices[resource]["sell"] - MARKET_STEP)
                prices[resource]["buy"] = max(prices[resource]["sell"] + 30, prices[resource]["buy"] - MARKET_STEP)
        market.append({
            "time": seconds(row["timestamp"]),
            "player": player,
            "kind": f"Market{row.get('type')}",
            "name": f"{row.get('type')} {resource}",
            "resource": resource,
            "lots": lots,
            "cost": {key: round(value, 4) for key, value in cost.items() if value},
            "income": {key: round(value, 4) for key, value in income.items() if value},
            "price_path": price_path,
            "source": "deterministic_v1_market_approximation",
            "confidence": "approximate_market_price",
        })
    return market, unresolved


def extract_economy_contract(economy: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Use economy.json as the canonical deduplicated economic evidence."""
    spending: list[dict[str, Any]] = []
    completions: list[dict[str, Any]] = []
    placements: list[dict[str, Any]] = []
    unresolved = defaultdict(int)

    for index, row in enumerate(economy.get("spending", []) if isinstance(economy.get("spending"), list) else []):
        if not isinstance(row, dict):
            unresolved["economy_spending_invalid_row"] += 1
            continue
        time = row.get("time")
        player = row.get("player")
        kind = row.get("kind")
        name = row.get("name")
        cost = normalized_cost(row.get("cost"))
        if not finite_number(time) or not isinstance(player, int) or not isinstance(kind, str) or not isinstance(name, str):
            unresolved["economy_spending_invalid_payload"] += 1
            continue
        spending.append({
            "time": round(float(time), 3),
            "player": player,
            "kind": kind,
            "name": name,
            "cost": cost,
            "income": {},
            "source": "economy.json.spending",
            "economy_index": index,
            "confidence": "economy_contract_base_cost",
        })

    for index, row in enumerate(economy.get("unit_completions", []) if isinstance(economy.get("unit_completions"), list) else []):
        if not isinstance(row, dict):
            unresolved["economy_completion_invalid_row"] += 1
            continue
        time = row.get("time")
        player = row.get("player")
        name = row.get("name")
        count = row.get("count", 1)
        if not finite_number(time) or not isinstance(player, int) or not isinstance(name, str) or not isinstance(count, int) or count <= 0:
            unresolved["economy_completion_invalid_payload"] += 1
            continue
        completions.append({
            "time": round(float(time), 3),
            "player": player,
            "name": name,
            "count": count,
            "producer_id": row.get("producer_id") if isinstance(row.get("producer_id"), int) else None,
            "source": "economy.json.unit_completions",
            "economy_index": index,
            "confidence": "economy_contract_exact_producer_linked_completion_estimate",
        })

    for index, row in enumerate(economy.get("building_placements", []) if isinstance(economy.get("building_placements"), list) else []):
        if not isinstance(row, dict):
            unresolved["economy_placement_invalid_row"] += 1
            continue
        time = row.get("time")
        player = row.get("player")
        kind = row.get("kind")
        name = row.get("name")
        position = numeric_position(row.get("position"))
        if not finite_number(time) or not isinstance(player, int) or not isinstance(kind, str) or not isinstance(name, str):
            unresolved["economy_placement_invalid_payload"] += 1
            continue
        placements.append({
            "time": round(float(time), 3),
            "player": player,
            "kind": kind,
            "name": name,
            "position": position,
            "footprint": row.get("footprint") if isinstance(row.get("footprint"), dict) else {},
            "source": "economy.json.building_placements",
            "economy_index": index,
            "confidence": "economy_contract_deduplicated_placement",
        })

    spending.sort(key=lambda row: (row["time"], row["player"], row["kind"], row["name"], row["economy_index"]))
    completions.sort(key=lambda row: (row["time"], row["player"], row["name"], row["producer_id"] or 0, row["economy_index"]))
    placements.sort(key=lambda row: (row["time"], row["player"], row["kind"], row["name"], json.dumps(row.get("position"), sort_keys=True)))
    contract = {
        "economy_json_counts": economy.get("counts", {}) if isinstance(economy.get("counts"), dict) else {},
        "methodology": economy.get("methodology", {}) if isinstance(economy.get("methodology"), dict) else {},
        "unresolved": {key: value for key, value in sorted(unresolved.items()) if value},
    }
    return spending, completions, placements, contract


def extract_tech_events(inputs: list[dict[str, Any]], rules: RuleTables) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, int]]:
    tech_starts: list[dict[str, Any]] = []
    tech_completions: list[dict[str, Any]] = []
    unresolved = defaultdict(int)
    for row in inputs:
        if row.get("type") != "Research":
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        time = seconds(row["timestamp"])
        player = row.get("player")
        name = payload.get("technology") or row.get("param")
        if not isinstance(player, int) or not isinstance(name, str):
            unresolved["Research_invalid_payload"] += 1
            continue
        entry = rules.tech(payload.get("technology_id"))
        research_time = entry.get("ResearchTime") if entry else None
        tech_starts.append({
            "time": time,
            "player": player,
            "name": name,
            "technology_id": payload.get("technology_id"),
            "producer_ids": list(object_ids(payload)),
            "research_time": clean_number(research_time) if finite_number(research_time) else None,
            "source": "game.input.research",
        })
        if finite_number(research_time):
            tech_completions.append({
                "time": round(time + float(research_time), 3),
                "player": player,
                "name": name,
                "technology_id": payload.get("technology_id"),
                "confidence": "research_time_estimate",
            })
        else:
            unresolved["Research_time"] += 1
    tech_starts.sort(key=lambda row: (row["time"], row["player"], row["name"]))
    tech_completions.sort(key=lambda row: (row["time"], row["player"], row["name"]))
    return tech_starts, tech_completions, unresolved


def extract_cancellations(inputs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, row in enumerate(inputs):
        if row.get("type") not in {"Unqueue", "Delete"}:
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        player = row.get("player")
        if not isinstance(player, int):
            continue
        rows.append({
            "time": seconds(row["timestamp"]),
            "player": player,
            "kind": row.get("type"),
            "name": payload.get("unit") or payload.get("building") or row.get("param"),
            "object_ids": list(object_ids(payload)),
            "source": "game.match.inputs",
            "input_index": index,
            "modeled_refund": False,
            "reason": "Cancellation/delete evidence is preserved separately; refunds are not reconstructed in V1 without exact queue/refund semantics.",
        })
    rows.sort(key=lambda item: (item["time"], item["player"], item["kind"], str(item.get("name"))))
    return rows


def build_checkpoints(game: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for player in game.get("match", {}).get("players", []):
        if not isinstance(player, dict) or not isinstance(player.get("number"), int):
            continue
        for row in player.get("timeseries", []) if isinstance(player.get("timeseries"), list) else []:
            if not isinstance(row, dict) or not finite_number(row.get("total_resources")):
                continue
            rows.append({
                "time": seconds(row["timestamp"]),
                "timestamp": row["timestamp"],
                "player": player["number"],
                "observed_total": float(row["total_resources"]),
                "observed_total_objects": row.get("total_objects"),
                "source": "game.match.players.timeseries.total_resources",
            })
    rows.sort(key=lambda row: (row["time"], row["player"]))
    return rows


def build_raw_evidence(game: dict[str, Any], lifetimes: dict[str, Any], economy: dict[str, Any], rules: RuleTables) -> RawEvidence:
    match = game.get("match")
    if not isinstance(match, dict):
        raise ValueError("game JSON does not contain match object")
    players = [
        {
            "number": player.get("number"),
            "name": player.get("name"),
            "color": player.get("color"),
            "civilization": player.get("civilization"),
            "start_position": numeric_position(player.get("position")),
        }
        for player in match.get("players", [])
        if isinstance(player, dict) and isinstance(player.get("number"), int)
    ]
    inputs, deduplication = normalize_inputs(match.get("inputs", []))
    spending, completions, building_placements, economy_contract = extract_economy_contract(economy)
    tech_starts, tech_completions, unresolved_tech = extract_tech_events(inputs, rules)
    market, unresolved_market = extract_market_events(inputs)
    cancellations = extract_cancellations(inputs)
    catalog = build_object_catalog(game, lifetimes)
    duration = float(game.get("summary", {}).get("duration_seconds") or match.get("duration") or 0.0)
    economy_counts = economy_contract.get("economy_json_counts", {})
    counts = {
        "players": len(players),
        "raw_inputs": len(match.get("inputs", [])) if isinstance(match.get("inputs"), list) else 0,
        "normalized_inputs": len(inputs),
        "spending_events": len(spending),
        "economy_json_spending_events": economy_counts.get("spending"),
        "market_events_preserved_not_charged": len(market),
        "cancellation_or_delete_events_preserved": len(cancellations),
        "unit_completions": len(completions),
        "economy_json_unit_completions": economy_counts.get("unit_completions"),
        "building_placements": len(building_placements),
        "economy_json_building_placements": economy_counts.get("building_placements"),
        "tech_starts": len(tech_starts),
        "tech_completions": len(tech_completions),
        "checkpoints": len(build_checkpoints(game)),
    }
    for key, value in {**unresolved_tech, **unresolved_market, **economy_contract.get("unresolved", {})}.items():
        if value:
            counts[f"unresolved_{key}"] = value
    return RawEvidence(
        players=players,
        duration=round(duration, 3),
        inputs=inputs,
        checkpoints=build_checkpoints(game),
        spending=spending,
        market=market,
        cancellations=cancellations,
        building_placements=building_placements,
        unit_completions=completions,
        tech_starts=tech_starts,
        tech_completions=tech_completions,
        catalog=catalog,
        counts=counts,
        deduplication={
            **deduplication,
            "economy_json_contract": {
                "schema": economy.get("schema"),
                "counts": economy_counts,
                "methodology": economy_contract.get("methodology", {}),
                "usage": (
                    "resource reconstruction uses economy.json spending, unit_completions, and building_placements "
                    "as the canonical deduplicated economic contract; broader normalized replay inputs are used for "
                    "worker/map state and preserved market/cancellation evidence."
                ),
            },
        },
    )


class ResourceLedger:
    def __init__(self, nodes: dict[int, ResourceNode], clusters: dict[str, list[int]], omitted_tree_count: int = 0):
        self.nodes = nodes
        self.clusters = clusters
        self.omitted_tree_count = omitted_tree_count
        self.transfer_events: list[dict[str, Any]] = []
        self._transfer_event_keys: set[tuple[Any, ...]] = set()
        self.capacity_residuals: list[dict[str, Any]] = []
        self.building_clearance_events: list[dict[str, Any]] = []
        self.touched_node_ids: set[int] = set()

    @classmethod
    def from_game(cls, game: dict[str, Any], inputs: list[dict[str, Any]]) -> "ResourceLedger":
        target_tree_ids = cls._tree_frontier_ids(game, inputs)
        nodes: dict[int, ResourceNode] = {}
        omitted_tree_count = 0
        for raw in game.get("match", {}).get("gaia", []) if isinstance(game.get("match", {}).get("gaia"), list) else []:
            if not isinstance(raw, dict) or not isinstance(raw.get("instance_id"), int):
                continue
            name = raw.get("name")
            family, subtype = resource_family(name)
            if family is None or name == "Relic":
                continue
            is_tree = subtype == "tree"
            if is_tree and raw["instance_id"] not in target_tree_ids:
                omitted_tree_count += 1
                continue
            position = numeric_position(raw.get("position"))
            if position is None:
                continue
            capacity = TREE_CAPACITY if is_tree else RESOURCE_CAPACITY.get(name, 0.0)
            if capacity <= 0:
                continue
            nodes[raw["instance_id"]] = ResourceNode(
                node_id=raw["instance_id"],
                name=name,
                family=family,
                subtype=subtype,
                position=position,
                starting_capacity=capacity,
                remaining=capacity,
            )
        clusters = cls._build_clusters(nodes)
        for cluster_id, node_ids in clusters.items():
            for node_id in node_ids:
                nodes[node_id].cluster_id = cluster_id
        return cls(nodes, clusters, omitted_tree_count)

    @staticmethod
    def _tree_frontier_ids(game: dict[str, Any], inputs: list[dict[str, Any]], radius: float = 3.0, limit_per_command: int = 12) -> set[int]:
        trees: list[tuple[int, dict[str, float]]] = []
        for raw in game.get("match", {}).get("gaia", []) if isinstance(game.get("match", {}).get("gaia"), list) else []:
            if not isinstance(raw, dict) or not isinstance(raw.get("instance_id"), int):
                continue
            family, subtype = resource_family(raw.get("name"))
            position = numeric_position(raw.get("position"))
            if family == "Wood" and subtype == "tree" and position is not None:
                trees.append((raw["instance_id"], position))
        ids: set[int] = set()
        tree_positions = {node_id: position for node_id, position in trees}
        for row in inputs:
            if row.get("type") not in {"Gather", "Gather Point"}:
                continue
            name = row.get("param")
            family, subtype = resource_family(name)
            if family != "Wood" or subtype != "tree":
                continue
            payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
            target_id = payload.get("target_id")
            center = tree_positions.get(target_id) if isinstance(target_id, int) else None
            center = center or numeric_position(row.get("position"))
            if center is None:
                continue
            nearby = sorted(
                (
                    (math.hypot(position["x"] - center["x"], position["y"] - center["y"]), node_id)
                    for node_id, position in trees
                    if math.hypot(position["x"] - center["x"], position["y"] - center["y"]) <= radius
                ),
                key=lambda item: (round(item[0], 6), item[1]),
            )
            ids.update(node_id for _, node_id in nearby[:limit_per_command])
        return ids

    @staticmethod
    def _build_clusters(nodes: dict[int, ResourceNode]) -> dict[str, list[int]]:
        by_kind: dict[tuple[str, str], list[ResourceNode]] = defaultdict(list)
        for node in nodes.values():
            if node.subtype == "tree":
                by_kind[(node.family, f"tree:{node.node_id}")].append(node)
            else:
                by_kind[(node.family, node.subtype)].append(node)
        clusters: dict[str, list[int]] = {}
        for (family, subtype), group in by_kind.items():
            if subtype.startswith("tree:"):
                node = group[0]
                clusters[f"{family.lower()}-tree-frontier-{node.node_id}"] = [node.node_id]
                continue
            radius = {
                "mine": 1.6,
                "berries": 2.2,
                "herdable": 6.0,
                "wild": 4.0,
            }.get(subtype, 2.0)
            remaining = {node.node_id: node for node in group}
            cluster_index = 1
            while remaining:
                start_id = min(remaining)
                stack = [start_id]
                members: list[int] = []
                while stack:
                    node_id = stack.pop()
                    node = remaining.pop(node_id, None)
                    if node is None:
                        continue
                    members.append(node_id)
                    for other_id, other in list(remaining.items()):
                        if math.hypot(node.position["x"] - other.position["x"], node.position["y"] - other.position["y"]) <= radius:
                            stack.append(other_id)
                clusters[f"{family.lower()}-{subtype}-{cluster_index}"] = sorted(members)
                cluster_index += 1
        return clusters

    def consume(self, family: str, amount: float, player: int, time: float, target_id: int | None = None, position: dict[str, float] | None = None, reason: str = "worker_extraction") -> tuple[float, list[dict[str, Any]]]:
        if amount <= 0:
            return 0.0, []
        candidates = self._candidate_nodes(family, target_id, position)
        remaining = amount
        taken_total = 0.0
        details: list[dict[str, Any]] = []
        prior_target = target_id
        for node in candidates:
            if remaining <= 0:
                break
            before = node.remaining
            taken = node.consume(remaining, player, time)
            if taken <= 0:
                continue
            self.touched_node_ids.add(node.node_id)
            remaining -= taken
            taken_total += taken
            details.append({
                "node_id": node.node_id,
                "family": node.family,
                "amount": round(taken, 4),
                "remaining": round(node.remaining, 4),
            })
            if prior_target is not None and node.node_id != prior_target:
                transfer_key = (player, family, prior_target, node.node_id, reason)
                if transfer_key not in self._transfer_event_keys:
                    self._transfer_event_keys.add(transfer_key)
                    self.transfer_events.append({
                        "time": round(time, 3),
                        "player": player,
                        "family": family,
                        "from_node_id": prior_target,
                        "to_node_id": node.node_id,
                        "reason": "selected node depleted; deterministic adjacent transfer",
                    })
                prior_target = node.node_id
        if remaining > 0.001:
            self.capacity_residuals.append({
                "time": round(time, 3),
                "player": player,
                "family": family,
                "requested": round(amount, 4),
                "unallocated": round(remaining, 4),
                "target_id": target_id,
                "reason": reason,
            })
        return taken_total, details

    def _candidate_nodes(self, family: str, target_id: int | None, position: dict[str, float] | None) -> list[ResourceNode]:
        if target_id in self.nodes:
            target = self.nodes[target_id]
            if target.family == family:
                cluster_ids = self.clusters.get(target.cluster_id or "", [target.node_id])
                return sorted(
                    (self.nodes[node_id] for node_id in cluster_ids if self.nodes[node_id].family == family),
                    key=lambda node: (
                        0 if node.node_id == target_id else 1,
                        math.hypot(node.position["x"] - target.position["x"], node.position["y"] - target.position["y"]),
                        node.node_id,
                    ),
                )
        candidates = [node for node in self.nodes.values() if node.family == family]
        if position is not None:
            return sorted(
                candidates,
                key=lambda node: (
                    math.hypot(node.position["x"] - position["x"], node.position["y"] - position["y"]),
                    node.node_id,
                ),
            )[:16]
        return sorted(candidates, key=lambda node: node.node_id)

    def allocate_checkpoint_correction(self, player: int, time: float, corrections: dict[str, float], positions: dict[str, dict[str, float] | None]) -> tuple[dict[str, float], dict[str, float]]:
        allocated = {resource: 0.0 for resource in RESOURCE_KEYS}
        residual = {resource: 0.0 for resource in RESOURCE_KEYS}
        for resource, amount in corrections.items():
            if amount <= 0:
                residual[resource] += amount
                continue
            taken, _ = self.consume(resource, amount, player, time, position=positions.get(resource), reason="checkpoint_reconciliation")
            allocated[resource] += taken
            if taken + 0.001 < amount:
                residual[resource] += amount - taken
        return allocated, residual

    def clear_for_building(
        self,
        bounds: tuple[float, float, float, float] | None,
        time: float,
        player: int,
        building: str,
    ) -> list[int]:
        if bounds is None:
            return []
        cleared: list[int] = []
        for node in sorted(self.nodes.values(), key=lambda item: item.node_id):
            overlaps = (
                resource_tile_overlaps_bounds(node.position, bounds)
                if node.family == "Wood"
                else position_in_bounds(node.position, bounds)
            )
            if node.remaining <= 0.0001 or not overlaps:
                continue
            remaining_before = node.remaining
            node.remaining = 0.0
            node.touched = True
            node.depleted_time = round(time, 3)
            self.touched_node_ids.add(node.node_id)
            cleared.append(node.node_id)
            self.building_clearance_events.append({
                "time": round(time, 3),
                "player": player,
                "building": building,
                "node_id": node.node_id,
                "resource": node.name,
                "family": node.family,
                "position": clean_position(node.position),
                "remaining_capacity_removed": clean_number(remaining_before),
                "credited_as_income": False,
                "reason": "building footprint proves the prior gatherable node was no longer available",
                "confidence": "observed_spatial_constraint",
            })
        return cleared

    def export_nodes(self) -> list[dict[str, Any]]:
        rows = []
        for node in sorted(self.nodes.values(), key=lambda item: item.node_id):
            if not node.touched and node.subtype == "tree":
                continue
            rows.append({
                "instance_id": node.node_id,
                "name": node.name,
                "family": node.family,
                "subtype": node.subtype,
                "position": clean_position(node.position),
                "cluster_id": node.cluster_id,
                "starting_capacity": clean_number(node.starting_capacity),
                "remaining": {
                    "central": clean_number(node.remaining),
                    "low": clean_number(max(0.0, node.remaining - 25.0 if node.touched else node.remaining)),
                    "high": clean_number(min(node.starting_capacity, node.remaining + 25.0 if node.touched else node.remaining)),
                },
                "depleted_time": clean_number(node.depleted_time) if node.depleted_time is not None else None,
                "depletion_probability": 0.95 if node.depleted_time is not None else (0.2 if node.touched else 0.0),
                "confidence": "probable" if node.depleted_time is not None else ("possible" if node.touched else "unobserved"),
                "extraction_by_player": {str(player): clean_number(amount) for player, amount in sorted(node.extraction_by_player.items()) if amount > 0},
                "timeline": [
                    {
                        "time": 0,
                        "remaining": {
                            "central": clean_number(node.starting_capacity),
                            "low": clean_number(node.starting_capacity),
                            "high": clean_number(node.starting_capacity),
                        },
                    },
                    {
                        "time": clean_number(node.depleted_time if node.depleted_time is not None else 0),
                        "remaining": {
                            "central": 0 if node.depleted_time is not None else clean_number(node.remaining),
                            "low": 0 if node.depleted_time is not None else clean_number(max(0.0, node.remaining - 25.0 if node.touched else node.remaining)),
                            "high": 0 if node.depleted_time is not None else clean_number(min(node.starting_capacity, node.remaining + 25.0 if node.touched else node.remaining)),
                        },
                    },
                ] if node.touched or node.depleted_time is not None else [],
            })
        return rows

    def export_clusters(self) -> list[dict[str, Any]]:
        rows = []
        for cluster_id, node_ids in sorted(self.clusters.items()):
            nodes = [self.nodes[node_id] for node_id in node_ids]
            if not any(node.touched for node in nodes):
                continue
            starting = sum(node.starting_capacity for node in nodes)
            remaining = sum(node.remaining for node in nodes)
            rows.append({
                "cluster_id": cluster_id,
                "family": nodes[0].family,
                "subtype": nodes[0].subtype,
                "node_ids": node_ids,
                "starting_capacity": clean_number(starting),
                "remaining": {
                    "central": clean_number(remaining),
                    "low": clean_number(max(0.0, remaining - 50.0)),
                    "high": clean_number(min(starting, remaining + 50.0)),
                },
                "confidence": "probable" if any(node.depleted_time is not None for node in nodes) else "possible",
                "timeline": [
                    {
                        "time": 0,
                        "remaining": {"central": clean_number(starting), "low": clean_number(starting), "high": clean_number(starting)},
                    },
                    {
                        "time": clean_number(max((node.depleted_time or 0.0) for node in nodes)),
                        "remaining": {
                            "central": clean_number(remaining),
                            "low": clean_number(max(0.0, remaining - 50.0)),
                            "high": clean_number(min(starting, remaining + 50.0)),
                        },
                    },
                ],
            })
        return rows


def clean_position(position: dict[str, float] | None) -> dict[str, float | int] | None:
    if position is None:
        return None
    return {"x": clean_number(position["x"], 4), "y": clean_number(position["y"], 4)}


class FarmLedger:
    def __init__(self) -> None:
        self.plots: dict[str, FarmPlot] = {}
        self.events: list[dict[str, Any]] = []
        self.inferred_generation_count = 0

    @staticmethod
    def plot_id(player: int, position: dict[str, float]) -> str:
        return f"p{player}:farm:{position['x']:.1f}:{position['y']:.1f}"

    @staticmethod
    def active_farm_tech(completed_techs: set[str]) -> str:
        if "Crop Rotation" in completed_techs:
            return "Crop Rotation"
        if "Heavy Plow" in completed_techs:
            return "Heavy Plow"
        if "Horse Collar" in completed_techs:
            return "Horse Collar"
        return "none"

    def ensure_generation(self, player: int, position: dict[str, float], time: float, source: str, completed_techs: set[str], auto_reseed_state: str, workers: Iterable[Any] = (), confidence: str = "observed") -> FarmPlot:
        pid = self.plot_id(player, position)
        plot = self.plots.get(pid)
        if plot is None:
            plot = FarmPlot(pid, player, position, auto_reseed_state)
            self.plots[pid] = plot
        else:
            plot.auto_reseed_state = auto_reseed_state
            plot.inactive_since = None
        tech = self.active_farm_tech(completed_techs)
        generation_id = f"{pid}:g{len(plot.generations) + 1}"
        generation = Generation(
            generation_id=generation_id,
            seed_time=round(time, 3),
            source=source,
            capacity=FARM_FOOD_CAPACITY[tech],
            remaining=FARM_FOOD_CAPACITY[tech],
            wood_cost=FARM_WOOD_COST,
            active_tech=tech,
            evidence=source,
            confidence=confidence,
            farmer_ids=sorted(workers, key=str),
        )
        plot.generations.append(generation)
        self.events.append({
            "time": round(time, 3),
            "player": player,
            "plot_id": pid,
            "kind": source,
            "generation_id": generation_id,
            "position": clean_position(position),
            "capacity": clean_number(generation.capacity),
            "active_tech": tech,
            "confidence": confidence,
        })
        return plot

    def assign_workers_to_farms(self, player: int, worker_ids: list[Any], position: dict[str, float] | None, time: float, limit_to_supported: bool = True) -> dict[Any, str]:
        active_plots = [
            plot for plot in self.plots.values()
            if plot.player == player and (not limit_to_supported or plot.active_generation(time) is not None)
        ]
        if position is not None:
            active_plots.sort(key=lambda plot: (math.hypot(plot.position["x"] - position["x"], plot.position["y"] - position["y"]), plot.plot_id))
        else:
            active_plots.sort(key=lambda plot: plot.plot_id)
        assignments: dict[Any, str] = {}
        for worker_id, plot in zip(sorted(worker_ids, key=str), active_plots):
            assignments[worker_id] = plot.plot_id
            plot.assigned_workers.add(worker_id)
        return assignments

    def consume(self, plot_id: str, amount: float, player_balance: dict[str, float], player: int, time: float, completed_techs: set[str], auto_reseed_state: str, worker_id: Any) -> tuple[float, float]:
        plot = self.plots.get(plot_id)
        if plot is None or amount <= 0:
            return 0.0, amount
        if plot.inactive_since is not None:
            return 0.0, amount
        generation = plot.active_generation(time)
        if generation is None:
            if self.maybe_auto_reseed(plot, time, player_balance, completed_techs, auto_reseed_state, worker_id):
                generation = plot.active_generation(time)
            else:
                plot.inactive_since = round(time, 3)
                plot.abandonment.append({
                    "time": round(time, 3),
                    "reason": "depleted farm had no supported reseed generation",
                    "auto_reseed_state": auto_reseed_state,
                    "confidence": "possible",
                })
                return 0.0, amount
        taken = min(generation.remaining, amount)
        generation.remaining = max(0.0, generation.remaining - taken)
        if generation.remaining <= 0.0001 and generation.depleted_time is None:
            generation.depleted_time = round(time, 3)
            if not self.maybe_auto_reseed(plot, time, player_balance, completed_techs, auto_reseed_state, worker_id):
                generation.disappearance_time = round(time, 3)
                plot.inactive_since = round(time, 3)
                plot.abandonment.append({
                    "time": round(time, 3),
                    "reason": "farm generation depleted and disappeared without explicit or affordable auto-reseed support",
                    "auto_reseed_state": auto_reseed_state,
                    "confidence": "possible",
                })
        return taken, amount - taken

    def maybe_auto_reseed(self, plot: FarmPlot, time: float, player_balance: dict[str, float], completed_techs: set[str], auto_reseed_state: str, worker_id: Any) -> bool:
        if auto_reseed_state != "on":
            self.events.append({
                "time": round(time, 3),
                "player": plot.player,
                "plot_id": plot.plot_id,
                "kind": "auto_reseed_not_supported",
                "reason": f"auto reseed state is {auto_reseed_state}",
                "confidence": "possible",
            })
            return False
        if player_balance.get("Wood", 0.0) + 0.001 < FARM_WOOD_COST:
            self.events.append({
                "time": round(time, 3),
                "player": plot.player,
                "plot_id": plot.plot_id,
                "kind": "auto_reseed_insufficient_wood",
                "wood": clean_number(player_balance.get("Wood", 0.0)),
                "confidence": "probable",
            })
            return False
        player_balance["Wood"] -= FARM_WOOD_COST
        self.inferred_generation_count += 1
        generation_id = f"{plot.plot_id}:auto{self.inferred_generation_count}"
        tech = self.active_farm_tech(completed_techs)
        generation = Generation(
            generation_id=generation_id,
            seed_time=round(time, 3),
            source="inferred_auto_reseed",
            capacity=FARM_FOOD_CAPACITY[tech],
            remaining=FARM_FOOD_CAPACITY[tech],
            wood_cost=FARM_WOOD_COST,
            active_tech=tech,
            evidence="active auto-reseed state, assigned farmer, and wood affordability",
            confidence="probable",
            farmer_ids=[worker_id],
        )
        plot.generations.append(generation)
        self.events.append({
            "time": round(time, 3),
            "player": plot.player,
            "plot_id": plot.plot_id,
            "kind": "inferred_auto_reseed",
            "generation_id": generation_id,
            "capacity": clean_number(generation.capacity),
            "active_tech": tech,
            "wood_cost": clean_number(FARM_WOOD_COST),
            "confidence": "probable",
        })
        return True

    def export(self) -> list[dict[str, Any]]:
        rows = []
        for plot in sorted(self.plots.values(), key=lambda value: value.plot_id):
            rows.append({
                "plot_id": plot.plot_id,
                "player": plot.player,
                "position": clean_position(plot.position),
                "auto_reseed_state": plot.auto_reseed_state,
                "assigned_worker_ids": sorted(plot.assigned_workers, key=str),
                "generations": [
                    {
                        "generation_id": generation.generation_id,
                        "seed_time": clean_number(generation.seed_time),
                        "source": generation.source,
                        "food_capacity": clean_number(generation.capacity),
                        "remaining": {
                            "central": clean_number(generation.remaining),
                            "low": clean_number(max(0.0, generation.remaining - 25.0)),
                            "high": clean_number(min(generation.capacity, generation.remaining + 25.0)),
                        },
                        "wood_cost": clean_number(generation.wood_cost),
                        "active_tech": generation.active_tech,
                        "depleted_time": clean_number(generation.depleted_time) if generation.depleted_time is not None else None,
                        "disappearance_time": clean_number(generation.disappearance_time) if generation.disappearance_time is not None else None,
                        "farmer_ids": generation.farmer_ids,
                        "evidence": generation.evidence,
                        "confidence": generation.confidence,
                    }
                    for generation in plot.generations
                ],
                "abandonment": plot.abandonment,
            })
        return rows


def technology_rate_multiplier(resource: str, completed_techs: set[str]) -> float:
    multiplier = 1.0
    if "Wheelbarrow" in completed_techs:
        multiplier *= 1.05
    if "Hand Cart" in completed_techs:
        multiplier *= 1.08
    if resource == "Wood":
        if "Double-Bit Axe" in completed_techs:
            multiplier *= 1.20
        if "Bow Saw" in completed_techs:
            multiplier *= 1.20
        if "Two-Man Saw" in completed_techs:
            multiplier *= 1.10
    if resource == "Gold":
        if "Gold Mining" in completed_techs:
            multiplier *= 1.15
        if "Gold Shaft Mining" in completed_techs:
            multiplier *= 1.15
    if resource == "Stone":
        if "Stone Mining" in completed_techs:
            multiplier *= 1.15
        if "Stone Shaft Mining" in completed_techs:
            multiplier *= 1.15
    return multiplier


def assignment_rate(assignment: Assignment, completed_techs: set[str]) -> float:
    if assignment.family not in RESOURCE_KEYS or assignment.state != "gathering":
        return 0.0
    base = BASE_GATHER_RATES[assignment.family]
    subtype = SUBTYPE_RATE_MULTIPLIERS.get(assignment.subtype, SUBTYPE_RATE_MULTIPLIERS["unknown"])
    return base * subtype * technology_rate_multiplier(assignment.family, completed_techs)


def uncertainty_width(central_total: float, context: dict[str, Any] | None) -> float:
    context = context or {}
    since_checkpoint = float(context.get("seconds_since_checkpoint", 300.0) or 0.0)
    to_checkpoint = float(context.get("seconds_to_checkpoint", 300.0) or 0.0)
    checkpoint_distance = max(0.0, min(since_checkpoint, to_checkpoint))
    event_density = max(0.0, float(context.get("events_nearby", 0.0) or 0.0))
    unresolved = abs(float(context.get("unresolved_residual", 0.0) or 0.0))
    unsupported_capacity = abs(float(context.get("unsupported_capacity", 0.0) or 0.0))
    inferred_ratio = max(0.0, min(1.0, float(context.get("inferred_assignment_ratio", 0.0) or 0.0)))
    pass2_adjustment = abs(float(context.get("pass2_adjustment_abs", 0.0) or 0.0))
    soft_pressure = abs(float(context.get("soft_backward_pressure_total", 0.0) or 0.0))

    width = 4.0
    width += min(90.0, checkpoint_distance * 0.18)
    width += max(0.0, 18.0 - event_density * 2.5)
    width += min(160.0, unresolved * 0.35)
    width += min(120.0, unsupported_capacity * 0.25)
    width += inferred_ratio * 55.0
    width += min(100.0, pass2_adjustment * 0.2)
    width += min(140.0, soft_pressure * 0.015)
    if context.get("checkpoint_strong"):
        width *= 0.35
    if context.get("explicit_worker_majority"):
        width *= 0.85
    return round(max(2.0, min(max(30.0, central_total * 0.42 + unresolved), width)), 4)


def likely_states(central: dict[str, float], observed_total: float | None, spread: float) -> list[dict[str, Any]]:
    """Return deterministic complete states with correlated totals."""
    base_total = total_resources(central)
    target_total = observed_total if observed_total is not None else base_total
    if base_total <= 0:
        scaled = {resource: 0.0 for resource in RESOURCE_KEYS}
    else:
        scaled = {resource: max(0.0, central[resource] * target_total / base_total) for resource in RESOURCE_KEYS}
    variants = [scaled]
    pairs = [("Food", "Wood"), ("Wood", "Gold"), ("Gold", "Stone"), ("Food", "Stone")]
    for positive, negative in pairs:
        amount = min(spread, scaled.get(negative, 0.0), max(0.0, target_total - scaled.get(positive, 0.0)))
        variant = dict(scaled)
        variant[positive] += amount
        variant[negative] -= amount
        variants.append(variant)
        variant = dict(scaled)
        amount = min(spread, scaled.get(positive, 0.0), max(0.0, target_total - scaled.get(negative, 0.0)))
        variant[positive] -= amount
        variant[negative] += amount
        variants.append(variant)
    normalized = []
    for variant in variants:
        drift = target_total - total_resources(variant)
        variant["Food"] += drift
        normalized.append({
            "resources": clean_resources(variant),
            "total": clean_number(total_resources(variant)),
        })
    unique: dict[str, dict[str, Any]] = {}
    for state in normalized:
        unique[json.dumps(state, sort_keys=True)] = state
    return [unique[key] for key in sorted(unique)]


def ranges_from_states(states: list[dict[str, Any]]) -> dict[str, dict[str, float | int]]:
    result: dict[str, dict[str, float | int]] = {}
    for resource in RESOURCE_KEYS:
        values = [float(state["resources"][resource]) for state in states]
        result[resource] = {"low": clean_number(min(values)), "high": clean_number(max(values))}
    totals = [float(state["total"]) for state in states]
    result["Total"] = {"low": clean_number(min(totals)), "high": clean_number(max(totals))}
    return result


def feasible_ranges(central: dict[str, float], observed_total: float | None, affordability_floor: dict[str, float], slack: float) -> dict[str, dict[str, float | int]]:
    total = total_resources(central)
    ranges: dict[str, dict[str, float | int]] = {}
    for resource in RESOURCE_KEYS:
        requested_low = max(0.0, float(affordability_floor.get(resource, 0.0)))
        low = min(float(central[resource]), requested_low)
        high = max(float(central[resource]), total - sum(max(0.0, affordability_floor.get(other, 0.0)) for other in RESOURCE_KEYS if other != resource) + slack)
        ranges[resource] = {"low": clean_number(low), "high": clean_number(max(low, high))}
    strict_total = observed_total is not None
    ranges["Total"] = {
        "low": clean_number(total if strict_total else max(0.0, total - slack)),
        "high": clean_number(total if strict_total else total + slack),
    }
    return ranges


def resource_capacity_from_catalog(evidence: RawEvidence) -> dict[str, dict[str, float]]:
    totals = {resource: {"modeled_capacity": 0.0, "observed_nodes": 0.0} for resource in RESOURCE_KEYS}
    for info in evidence.catalog.values():
        family, subtype = resource_family(info.name)
        if family not in RESOURCE_KEYS or subtype == "farm":
            continue
        if subtype == "tree":
            capacity = TREE_CAPACITY
        else:
            capacity = RESOURCE_CAPACITY.get(info.name or "", 0.0)
        if capacity <= 0:
            continue
        totals[family]["modeled_capacity"] += capacity
        totals[family]["observed_nodes"] += 1
    return {
        resource: {
            "modeled_capacity": clean_number(values["modeled_capacity"]),
            "observed_nodes": clean_number(values["observed_nodes"]),
        }
        for resource, values in totals.items()
    }


def raw_collection_capacity_intervals(evidence: RawEvidence) -> dict[int, list[dict[str, Any]]]:
    player_numbers = [player["number"] for player in evidence.players]
    input_events = defaultdict(list)
    for row in evidence.inputs:
        input_events[seconds(row["timestamp"])].append(row)
    event_times = {0.0, evidence.duration}
    event_times.update(input_events)
    event_times.update(row["time"] for row in evidence.spending)
    event_times.update(row["time"] for row in evidence.checkpoints)
    ordered = sorted(time for time in event_times if 0 <= time <= evidence.duration + 0.001)
    assignments: dict[Any, Assignment] = {}
    intervals = {player: [] for player in player_numbers}

    def set_workers(row: dict[str, Any], state: str, family: str | None = None, subtype: str = "unknown") -> None:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        player = row.get("player")
        if not isinstance(player, int):
            return
        for worker_id in [worker for worker in object_ids(payload) if is_worker(worker, evidence.catalog)]:
            assignments[worker_id] = Assignment(
                worker_id=worker_id,
                player=player,
                state=state,
                family=family,
                subtype=subtype,
                confidence="observed" if family else "observed_non_gather",
            )

    last_time = ordered[0] if ordered else 0.0
    for current_time in ordered:
        if current_time > last_time:
            dt = current_time - last_time
            capacity = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
            explicit_workers = {player: 0 for player in player_numbers}
            for assignment in assignments.values():
                if assignment.state != "gathering" or assignment.family not in RESOURCE_KEYS:
                    continue
                max_rate = BASE_GATHER_RATES[assignment.family] * SUBTYPE_RATE_MULTIPLIERS.get(assignment.subtype, 0.75) * 1.75
                capacity[assignment.player][assignment.family] += max_rate * dt
                explicit_workers[assignment.player] += 1
            for player in player_numbers:
                row = {
                    "start": round(last_time, 3),
                    "end": round(current_time, 3),
                    "max_collect": clean_resources(capacity[player]),
                    "explicit_gather_workers": explicit_workers[player],
                    "source": "raw input gather/order states with generous deterministic V1 max-rate envelope",
                }
                intervals[player].append(row)
        for row in sorted(input_events.get(current_time, []), key=exact_sort_key):
            kind = row.get("type")
            name = resource_name_from_target(row, evidence.catalog)
            family, subtype = resource_family(name)
            if kind in {"Gather", "Order"} and family in RESOURCE_KEYS:
                set_workers(row, "gathering", family, subtype)
            elif kind in {"Move", "Stop", "Garrison", "Ungarrison", "Target", "Build", "Reseed"}:
                set_workers(row, {
                    "Move": "moving",
                    "Stop": "idle",
                    "Garrison": "garrisoned",
                    "Ungarrison": "moving",
                    "Target": "combat",
                    "Build": "constructing",
                    "Reseed": "constructing",
                }.get(kind, "uncertain"))
        last_time = current_time
    return intervals


def interval_capacity_lookup(intervals: list[dict[str, Any]], start: float, end: float) -> dict[str, float]:
    capacity = {resource: 0.0 for resource in RESOURCE_KEYS}
    if end <= start:
        return capacity
    for row in intervals:
        row_start = float(row["start"])
        row_end = float(row["end"])
        overlap = max(0.0, min(end, row_end) - max(start, row_start))
        if overlap <= 0:
            continue
        row_duration = max(0.001, row_end - row_start)
        fraction = overlap / row_duration
        for resource in RESOURCE_KEYS:
            capacity[resource] += float(row["max_collect"].get(resource, 0.0)) * fraction
    return capacity


def run_backward_requirements(evidence: RawEvidence, rules: RuleTables) -> dict[str, Any]:
    """Independent backward feasibility pass over raw evidence and rules only."""
    del rules  # Rule costs and timings are already materialized in RawEvidence from immutable inputs.
    signature = inspect.signature(run_backward_requirements)
    player_numbers = [player["number"] for player in evidence.players]
    collection_intervals = raw_collection_capacity_intervals(evidence)
    checkpoints_by_player = defaultdict(list)
    spending_by_player = defaultdict(list)
    for row in evidence.checkpoints:
        checkpoints_by_player[row["player"]].append(row)
    for row in evidence.spending:
        spending_by_player[row["player"]].append(row)

    requirements_by_player: dict[int, list[dict[str, Any]]] = defaultdict(list)
    requirement_series_by_player: dict[int, list[dict[str, Any]]] = defaultdict(list)
    checkpoint_constraints: dict[int, list[dict[str, Any]]] = defaultdict(list)
    latest_collection: dict[int, list[dict[str, Any]]] = defaultdict(list)
    infeasible: list[dict[str, Any]] = []

    for player in player_numbers:
        times = {0.0, evidence.duration}
        times.update(row["time"] for row in spending_by_player[player])
        times.update(row["time"] for row in checkpoints_by_player[player])
        ordered = sorted(time for time in times if 0 <= time <= evidence.duration + 0.001)
        future_req = {resource: 0.0 for resource in RESOURCE_KEYS}
        next_time = ordered[-1] if ordered else evidence.duration
        for time in reversed(ordered):
            if next_time > time:
                capacity = interval_capacity_lookup(collection_intervals[player], time, next_time)
                reductions = {}
                for resource in RESOURCE_KEYS:
                    reduction = min(future_req[resource], capacity[resource])
                    if reduction > 0.001:
                        reductions[resource] = reduction
                    future_req[resource] = max(0.0, future_req[resource] - capacity[resource])
                if reductions:
                    latest_collection[player].append({
                        "start": clean_number(time),
                        "end": clean_number(next_time),
                        "required_collection_absorbed": clean_resources(reductions),
                        "remaining_requirement_before_interval": clean_resources(future_req),
                        "source": "raw backward max collection envelope",
                    })

            for checkpoint in sorted((row for row in checkpoints_by_player[player] if row["time"] == time), key=lambda row: row["observed_total"]):
                observed = float(checkpoint["observed_total"])
                low_sum = total_resources(future_req)
                lows = dict(future_req)
                highs = {}
                for resource in RESOURCE_KEYS:
                    other_lows = sum(lows[other] for other in RESOURCE_KEYS if other != resource)
                    highs[resource] = max(lows[resource], observed - other_lows)
                residual = max(0.0, low_sum - observed)
                if residual > 0.001:
                    infeasible.append({
                        "time": clean_number(time),
                        "player": player,
                        "kind": "aggregate_checkpoint_requirement_exceeds_observed_total",
                        "observed_total": clean_number(observed),
                        "minimum_required_total": clean_number(low_sum),
                        "unresolved_residual": clean_number(residual),
                    })
                checkpoint_constraints[player].append({
                    "time": clean_number(time),
                    "aggregate_total": clean_number(observed),
                    "minimum_balance": clean_resources(lows),
                    "resource_high_envelope": clean_resources(highs),
                    "minimum_total": clean_number(low_sum),
                    "unresolved_requirement_overage": clean_number(residual),
                    "constraint": "aggregate stockpile checkpoint binds the sum of resources, not composition",
                })

            same_time_spending = sorted(
                (row for row in spending_by_player[player] if row["time"] == time),
                key=lambda row: (row["kind"], row["name"], row.get("economy_index", 0)),
                reverse=True,
            )
            cumulative_same_time = {resource: 0.0 for resource in RESOURCE_KEYS}
            for event in same_time_spending:
                cost = {resource: float(event.get("cost", {}).get(resource, 0.0)) for resource in RESOURCE_KEYS}
                before = {resource: future_req[resource] + cumulative_same_time[resource] + cost[resource] for resource in RESOURCE_KEYS}
                requirements_by_player[player].append({
                    "time": clean_number(event["time"]),
                    "event": f"{event['kind']}: {event['name']}",
                    "minimum_before_spend": clean_resources(before),
                    "cost": clean_resources(cost),
                    "future_requirement_after_spend": clean_resources(future_req),
                    "constraint_class": "hard_affordability",
                    "coverage": "observed order-time spend",
                    "confidence": "backward_propagated_rule_cost_requirement",
                })
                add_resources(cumulative_same_time, cost, 1.0)
            add_resources(future_req, cumulative_same_time, 1.0)
            requirement_series_by_player[player].append({
                "time": clean_number(time),
                "minimum_balance": clean_resources(future_req),
                "minimum_total": clean_number(total_resources(future_req)),
                "constraint_class": "soft_backward_pressure",
                "coverage": "incomplete_raw_collection_envelope",
                "source": "backward propagated future spending minus raw plausible collection",
            })
            next_time = time

        requirements_by_player[player].sort(key=lambda row: (row["time"], row["event"]))
        requirement_series_by_player[player].sort(key=lambda row: row["time"])
        checkpoint_constraints[player].sort(key=lambda row: row["time"])
        latest_collection[player].sort(key=lambda row: (row["start"], row["end"]))

    capacities = resource_capacity_from_catalog(evidence)
    total_costs = {resource: 0.0 for resource in RESOURCE_KEYS}
    for event in evidence.spending:
        add_resources(total_costs, event.get("cost", {}), 1.0)
    node_capacity_requirements = []
    for resource in RESOURCE_KEYS:
        required_collection = max(0.0, total_costs[resource] - STARTING_STOCKPILE[resource] * max(1, len(player_numbers)))
        capacity = float(capacities[resource]["modeled_capacity"])
        residual = max(0.0, required_collection - capacity)
        node_capacity_requirements.append({
            "resource": resource,
            "minimum_collection_after_starts": clean_number(required_collection),
            "observed_map_capacity": clean_number(capacity),
            "unresolved_capacity_gap": clean_number(residual),
            "confidence": "global_raw_capacity_bound",
        })
        if residual > 0.001:
            infeasible.append({
                "kind": "resource_capacity_requirement_exceeds_observed_map_capacity",
                "resource": resource,
                "minimum_collection_after_starts": clean_number(required_collection),
                "observed_map_capacity": clean_number(capacity),
                "unresolved_residual": clean_number(residual),
            })

    capacity_demands_by_player: dict[int, list[dict[str, Any]]] = defaultdict(list)
    shared_capacity_envelopes: list[dict[str, Any]] = []
    all_capacity_times = sorted({
        float(row["time"])
        for rows in requirement_series_by_player.values()
        for row in rows
    })
    for player, rows in requirement_series_by_player.items():
        for row in rows:
            minimum = row.get("minimum_balance", {})
            capacity_demands_by_player[player].append({
                "time": row["time"],
                "minimum_balance": minimum,
                "minimum_collection_after_start": clean_resources({
                    resource: max(0.0, float(minimum.get(resource, 0.0)) - STARTING_STOCKPILE[resource])
                    for resource in RESOURCE_KEYS
                }),
                "source": "player/time backward requirement against shared map capacity",
            })
    for time in all_capacity_times:
        summed = {resource: 0.0 for resource in RESOURCE_KEYS}
        for player in player_numbers:
            latest = None
            for row in capacity_demands_by_player.get(player, []):
                if float(row["time"]) <= time + 0.001:
                    latest = row
                else:
                    break
            if latest:
                add_resources(summed, latest.get("minimum_collection_after_start", {}), 1.0)
        shared_capacity_envelopes.append({
            "time": clean_number(time),
            "summed_player_minimum_collection_after_start": clean_resources(summed),
            "shared_observed_capacity": {
                resource: capacities[resource]["modeled_capacity"] for resource in RESOURCE_KEYS
            },
            "unresolved_shared_capacity_gap": clean_resources({
                resource: max(0.0, summed[resource] - float(capacities[resource]["modeled_capacity"]))
                for resource in RESOURCE_KEYS
            }),
            "source": "global contested capacity ledger; ownership/allocation remains uncertain",
        })

    nonfarm_food_capacity = sum(
        float(RESOURCE_CAPACITY.get(info.name or "", 0.0))
        for info in evidence.catalog.values()
        if resource_family(info.name)[0] == "Food" and resource_family(info.name)[1] not in {"farm", "unknown"}
    )
    farm_requirements = []
    for player in player_numbers:
        food_spend = sum(float(row.get("cost", {}).get("Food", 0.0)) for row in spending_by_player[player])
        explicit_generations = sum(1 for row in evidence.building_placements if row["player"] == player and row.get("name") == "Farm")
        explicit_farm_wood = [
            row for row in spending_by_player[player]
            if row.get("name") == "Farm" and row.get("cost", {}).get("Wood")
        ]
        demand_if_player_controls_all_nonfarm = max(0.0, food_spend - STARTING_STOCKPILE["Food"] - nonfarm_food_capacity)
        demand_if_player_controls_no_nonfarm = max(0.0, food_spend - STARTING_STOCKPILE["Food"])
        minimum_generations = int(math.ceil(demand_if_player_controls_all_nonfarm / FARM_FOOD_CAPACITY["none"])) if demand_if_player_controls_all_nonfarm > 0 else 0
        maximum_generations = int(math.ceil(demand_if_player_controls_no_nonfarm / FARM_FOOD_CAPACITY["none"])) if demand_if_player_controls_no_nonfarm > 0 else 0
        missing_generations = max(0, minimum_generations - explicit_generations)
        farm_requirements.append({
            "player": player,
            "first_explicit_farm_time": clean_number(min((row["time"] for row in explicit_farm_wood), default=0.0)),
            "explicit_farm_or_reseed_generations": explicit_generations,
            "minimum_generations_by_food_demand": minimum_generations,
            "maximum_generations_by_food_demand": maximum_generations,
            "unsupported_generation_gap": missing_generations,
            "food_spending_pressure": clean_number(food_spend),
            "nonfarm_food_capacity_feasible_allocation": {
                "low": 0,
                "high": clean_number(nonfarm_food_capacity),
                "reason": "shared food ownership/allocation is uncertain; V1 does not split it evenly between players",
            },
            "confidence": "coarse_backward_food_demand_requirement",
        })
        if missing_generations:
            infeasible.append({
                "kind": "farm_generation_requirement_not_supported_by_explicit_generations",
                "player": player,
                "unsupported_generation_gap": missing_generations,
                "confidence": "possible",
            })

    return {
        "principle": (
            "Backward pass uses RawEvidence spending, checkpoints, raw input gather states, cancellations, "
            "farm placements, map catalog capacities, and immutable rule-materialized costs only."
        ),
        "api_signature": str(signature),
        "requirements_by_player": {
            str(player): rows for player, rows in sorted(requirements_by_player.items())
        },
        "requirements_series_by_player": {
            str(player): rows for player, rows in sorted(requirement_series_by_player.items())
        },
        "latest_plausible_collection": {
            str(player): rows for player, rows in sorted(latest_collection.items())
        },
        "farm_generation_requirements": farm_requirements,
        "node_capacity_requirements": node_capacity_requirements,
        "capacity_demands_by_player": {
            str(player): rows for player, rows in sorted(capacity_demands_by_player.items())
        },
        "shared_capacity_envelopes": shared_capacity_envelopes,
        "checkpoint_constraints": {
            str(player): rows for player, rows in sorted(checkpoint_constraints.items())
        },
        "infeasible_or_residual_constraints": infeasible,
        "market_evidence_preserved": [
            {
                "time": clean_number(row["time"]),
                "player": row["player"],
                "kind": row["kind"],
                "name": row["name"],
                "reason": "Preserved as exposed evidence; not charged against the economy.json spending contract in V1.",
            }
            for row in evidence.market[:200]
        ],
        "cancellations_preserved": evidence.cancellations[:200],
        "does_not_accept_pass1": "pass1" not in signature.parameters,
    }


def audit_observation_semantics(evidence: RawEvidence) -> dict[str, Any]:
    by_player = defaultdict(list)
    for row in evidence.checkpoints:
        by_player[row["player"]].append(row)

    player_evidence = []
    monotonic_failures = 0
    cadence_values = []
    for player in sorted(by_player):
        rows = by_player[player]
        totals = [row["observed_total"] for row in rows]
        monotonic_failures += sum(1 for before, after in zip(totals, totals[1:]) if after < before)
        deltas = [round(after["time"] - before["time"], 3) for before, after in zip(rows, rows[1:])]
        cadence_values.extend(deltas)
        first = rows[0] if rows else None
        spend_before_first = {resource: 0.0 for resource in RESOURCE_KEYS}
        for event in evidence.spending:
            if event["player"] == player and first is not None and event["time"] <= first["time"]:
                add_resources(spend_before_first, event.get("cost", {}), 1.0)
                add_resources(spend_before_first, event.get("income", {}), -1.0)
        expected_no_income = STARTING_TOTAL - total_resources(spend_before_first)
        player_evidence.append({
            "player": player,
            "first_checkpoint_time": clean_number(first["time"]) if first else None,
            "first_observed_total": clean_number(first["observed_total"]) if first else None,
            "standard_start_minus_observed_precheck_spending": clean_number(expected_no_income) if first else None,
            "absolute_difference": clean_number(abs(expected_no_income - first["observed_total"])) if first else None,
            "timeseries_rows": len(rows),
            "decreases": sum(1 for before, after in zip(totals, totals[1:]) if after < before),
        })

    spending_windows = []
    spending_window_support = 0
    for event in evidence.spending:
        if not event.get("cost"):
            continue
        rows = by_player[event["player"]]
        prior = None
        after = None
        for row in rows:
            if row["time"] <= event["time"]:
                prior = row
            elif row["time"] > event["time"]:
                after = row
                break
        if prior is not None and after is not None and after["time"] - prior["time"] <= 90:
            observed_delta = after["observed_total"] - prior["observed_total"]
            cost_total = total_resources(event.get("cost", {}))
            supports_current = observed_delta < max(0.0, cost_total * 0.35)
            if supports_current and cost_total >= 50:
                spending_window_support += 1
            spending_windows.append({
                "event_time": clean_number(event["time"]),
                "player": event["player"],
                "event": f"{event['kind']}: {event['name']}",
                "cost_total": clean_number(cost_total),
                "prior_checkpoint": {"time": clean_number(prior["time"]), "total": clean_number(prior["observed_total"])},
                "next_checkpoint": {"time": clean_number(after["time"]), "total": clean_number(after["observed_total"])},
                "observed_delta": clean_number(observed_delta),
                "supports_current_stockpile_over_cumulative": supports_current,
            })
        if len(spending_windows) >= 8:
            break

    cadence = {
        "min_seconds": clean_number(min(cadence_values)) if cadence_values else None,
        "median_seconds": clean_number(statistics.median(cadence_values)) if cadence_values else None,
        "max_seconds": clean_number(max(cadence_values)) if cadence_values else None,
    }
    first_differences = [
        item["absolute_difference"]
        for item in player_evidence
        if finite_number(item.get("absolute_difference"))
    ]
    start_match_count = sum(1 for value in first_differences if float(value) <= 0.001)
    start_matches = bool(first_differences) and start_match_count == len(first_differences)
    if not by_player:
        conclusion = "unavailable"
        confidence = "none"
        use_as_checkpoint = False
    else:
        support_score = 0
        support_score += 1 if start_matches else 0
        support_score += 1 if monotonic_failures > 0 else 0
        support_score += 1 if spending_window_support >= 2 else 0
        if monotonic_failures > 0 and (start_matches or spending_window_support >= 2):
            conclusion = "current_aggregate_stockpile"
            confidence = "medium_high" if start_matches and support_score >= 3 else "medium"
            use_as_checkpoint = True
        elif monotonic_failures > 0:
            conclusion = "non_cumulative_current_like_aggregate"
            confidence = "medium"
            use_as_checkpoint = True
        else:
            conclusion = "ambiguous_aggregate_statistic"
            confidence = "low"
            use_as_checkpoint = False
    return {
        "field": "game.match.players[].timeseries[].total_resources",
        "cadence": cadence,
        "evidence": {
            "standard_start_checks": player_evidence,
            "standard_start_match_count": start_match_count,
            "non_monotonic_decrease_count": monotonic_failures,
            "spending_window_current_stockpile_support_count": spending_window_support,
            "spending_windows": spending_windows,
        },
        "conclusion": conclusion,
        "confidence": confidence,
        "tolerance": 0.001,
        "carried_resources": (
            "The field behaves like current aggregate player stockpile. The replay export does not expose "
            "villager carried payloads directly, so carried resources are estimated separately and are not "
            "assumed to be included in checkpoint totals."
        ),
        "use_as_checkpoint": use_as_checkpoint,
        "limitation": "Resource-specific composition is not observed; only Food+Wood+Gold+Stone is constrained.",
    }


def player_start_positions(players: list[dict[str, Any]]) -> dict[int, dict[str, float] | None]:
    return {
        player["number"]: numeric_position(player.get("start_position")) if isinstance(player.get("start_position"), dict) else None
        for player in players
        if isinstance(player.get("number"), int)
    }


def starting_assignments(evidence: RawEvidence) -> dict[Any, Assignment]:
    assignments: dict[Any, Assignment] = {}
    for info in evidence.catalog.values():
        if info.owner is None or not is_worker(info.instance_id, evidence.catalog):
            continue
        assignments[info.instance_id] = Assignment(
            worker_id=info.instance_id,
            player=info.owner,
            state="uncertain",
            position=info.position,
            confidence="possible",
            reason="initial or first-observed villager without persistent economic command",
        )
    return assignments


def update_worker_state(history: dict[Any, list[dict[str, Any]]], assignment: Assignment, time: float) -> None:
    rows = history[assignment.worker_id]
    row = {
        "time": clean_number(time),
        "player": assignment.player,
        "state": assignment.state,
        "family": assignment.family,
        "subtype": assignment.subtype,
        "target_id": assignment.target_id,
        "farm_plot_id": assignment.farm_plot_id,
        "confidence": assignment.confidence,
        "reason": assignment.reason,
    }
    incompatible_states = {"gathering", "constructing", "moving", "garrisoned", "combat"}
    if (
        rows
        and rows[-1]["time"] == row["time"]
        and rows[-1]["state"] != row["state"]
        and rows[-1]["state"] in incompatible_states
        and row["state"] in incompatible_states
    ):
        rows[-1] = row
    elif not rows or rows[-1] != row:
        rows.append(row)


def assignment_from_gather(row: dict[str, Any], evidence: RawEvidence, farm_ledger: FarmLedger, time: float) -> list[Assignment]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    name = resource_name_from_target(row, evidence.catalog)
    family, subtype = resource_family(name)
    if family is None:
        return []
    target_id = payload.get("target_id") if isinstance(payload.get("target_id"), int) else None
    player = row.get("player")
    if not isinstance(player, int):
        return []
    workers = [worker for worker in object_ids(payload) if is_worker(worker, evidence.catalog)]
    assignments: list[Assignment] = []
    position = event_position(row)
    if subtype == "farm":
        farm_assignments = farm_ledger.assign_workers_to_farms(player, workers, position, time, limit_to_supported=True)
        for worker_id, plot_id in farm_assignments.items():
            assignments.append(Assignment(
                worker_id=worker_id,
                player=player,
                state="gathering",
                family="Food",
                subtype="farm",
                target_id=target_id,
                farm_plot_id=plot_id,
                position=position,
                confidence="observed",
                reason="explicit farm gather command assigned to supported plots",
            ))
        return assignments
    for worker_id in workers:
        assignments.append(Assignment(
            worker_id=worker_id,
            player=player,
            state="gathering",
            family=family,
            subtype=subtype,
            target_id=target_id,
            position=position,
            confidence="observed",
            reason=f"explicit gather command: {name}",
        ))
    return assignments


def resource_weights_from_activity(activity: dict[int, dict[str, float]], player: int) -> dict[str, float]:
    values = dict(activity.get(player, {}))
    total = sum(max(0.0, values.get(resource, 0.0)) for resource in RESOURCE_KEYS)
    if total <= 0:
        return {resource: 0.0 for resource in RESOURCE_KEYS}
    return {resource: max(0.0, values.get(resource, 0.0)) / total for resource in RESOURCE_KEYS}


def fallback_resource_weights(player: int, evidence: RawEvidence, current_time: float) -> dict[str, float]:
    # Deterministic broad default for hidden collection in sparse observation gaps.
    if current_time < 600:
        return {"Food": 0.55, "Wood": 0.3, "Gold": 0.1, "Stone": 0.05}
    if current_time < 1800:
        return {"Food": 0.38, "Wood": 0.34, "Gold": 0.18, "Stone": 0.10}
    return {"Food": 0.32, "Wood": 0.32, "Gold": 0.24, "Stone": 0.12}


def allocate_residual_by_weights(residual: float, weights: dict[str, float], balances: dict[str, float]) -> dict[str, float]:
    corrections = {resource: 0.0 for resource in RESOURCE_KEYS}
    if abs(residual) <= 0.001:
        return corrections
    if residual > 0:
        active_total = sum(max(0.0, weights.get(resource, 0.0)) for resource in RESOURCE_KEYS)
        if active_total <= 0:
            weights = {resource: 1.0 / len(RESOURCE_KEYS) for resource in RESOURCE_KEYS}
        for resource in RESOURCE_KEYS:
            corrections[resource] = residual * max(0.0, weights.get(resource, 0.0))
        drift = residual - total_resources(corrections)
        corrections["Food"] += drift
        return corrections
    remaining = -residual
    ordered = sorted(RESOURCE_KEYS, key=lambda resource: (-weights.get(resource, 0.0), resource))
    for resource in ordered:
        take = min(remaining, max(0.0, balances.get(resource, 0.0)))
        corrections[resource] -= take
        remaining -= take
        if remaining <= 0.001:
            break
    return corrections


def sample_from_state(
    time: float,
    player: int,
    balances: dict[str, float],
    carried: dict[str, float],
    spent_cumulative: dict[str, float],
    observed_total: float | None,
    checkpoint: dict[str, Any] | None,
    affordability_floor: dict[str, float],
    confidence_reason: str,
    uncertainty_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    central = {resource: max(0.0, balances.get(resource, 0.0)) for resource in RESOURCE_KEYS}
    central_total = total_resources(central)
    context = dict(uncertainty_context or {})
    if checkpoint:
        context.setdefault("checkpoint_strong", abs(float(checkpoint.get("unresolved_residual", 0.0))) <= 0.001)
        context.setdefault("unresolved_residual", abs(float(checkpoint.get("unresolved_residual", 0.0))))
    spread = uncertainty_width(central_total, context)
    states = likely_states(central, central_total, spread)
    return {
        "time": clean_number(time),
        "player": player,
        "central": {
            **clean_resources(central),
            "Total": clean_number(central_total),
        },
        "likely_ranges": ranges_from_states(states),
        "feasible_ranges": feasible_ranges(central, observed_total, affordability_floor, spread * 2),
        "likely_states": states,
        "carried_resources": {
            **clean_resources(carried),
            "Total": clean_number(total_resources(carried)),
            "method": "representative in-cycle carried payload estimate; not observed directly",
        },
        "spending_cumulative": {
            **clean_resources(spent_cumulative),
            "Total": clean_number(total_resources(spent_cumulative)),
        },
        "checkpoint": checkpoint,
        "confidence": {
            "level": "medium" if checkpoint else "low",
            "reason": confidence_reason,
        },
        "uncertainty_context": {
            **{key: clean_number(value) if finite_number(value) else value for key, value in sorted(context.items())},
            "scenario_band_width": clean_number(spread),
            "band_method": "deterministic evidence-responsive correlated scenarios",
        },
    }


def run_forward_filter(evidence: RawEvidence, rules: RuleTables, resource_ledger: ResourceLedger, farm_ledger: FarmLedger, sample_step: float = 30.0) -> dict[str, Any]:
    player_numbers = [player["number"] for player in evidence.players]
    balances = {player: dict(STARTING_STOCKPILE) for player in player_numbers}
    spent_cumulative = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
    carried = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
    completed_techs = {player: set() for player in player_numbers}
    auto_reseed = {player: "unknown" for player in player_numbers}
    assignments = starting_assignments(evidence)
    worker_history: dict[Any, list[dict[str, Any]]] = defaultdict(list)
    for assignment in assignments.values():
        update_worker_state(worker_history, assignment, 0.0)
    tc_gather_points: dict[int, dict[str, Any]] = {}
    samples = {player: [] for player in player_numbers}
    event_states = {player: [] for player in player_numbers}
    checkpoint_records = {player: [] for player in player_numbers}
    residuals = []
    corrections_by_player = {player: [] for player in player_numbers}
    income_cumulative = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
    interval_activity = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
    last_resource_position = {player: {resource: None for resource in RESOURCE_KEYS} for player in player_numbers}
    affordability_floor = {player: {resource: 0.0 for resource in RESOURCE_KEYS} for player in player_numbers}
    event_times_by_player = {player: [] for player in player_numbers}
    checkpoint_times_by_player = {player: [] for player in player_numbers}

    input_events = defaultdict(list)
    for row in evidence.inputs:
        input_events[seconds(row["timestamp"])].append(row)
        if isinstance(row.get("player"), int) and row["player"] in event_times_by_player:
            event_times_by_player[row["player"]].append(seconds(row["timestamp"]))
    spending_events = defaultdict(list)
    for row in evidence.spending:
        spending_events[row["time"]].append(row)
        if row["player"] in event_times_by_player:
            event_times_by_player[row["player"]].append(row["time"])
    placement_events = defaultdict(list)
    for row in evidence.building_placements:
        placement_events[row["time"]].append(row)
        if row["player"] in event_times_by_player:
            event_times_by_player[row["player"]].append(row["time"])
    completion_events = defaultdict(list)
    for row in evidence.unit_completions:
        completion_events[row["time"]].append(row)
        if row["player"] in event_times_by_player:
            event_times_by_player[row["player"]].append(row["time"])
    tech_completion_events = defaultdict(list)
    for row in evidence.tech_completions:
        tech_completion_events[row["time"]].append(row)
        if row["player"] in event_times_by_player:
            event_times_by_player[row["player"]].append(row["time"])
    checkpoint_events = defaultdict(list)
    for row in evidence.checkpoints:
        checkpoint_events[row["time"]].append(row)
        if row["player"] in checkpoint_times_by_player:
            checkpoint_times_by_player[row["player"]].append(row["time"])
            event_times_by_player[row["player"]].append(row["time"])

    times = {0.0, evidence.duration}
    times.update(round(value * sample_step, 3) for value in range(0, int(math.ceil(evidence.duration / sample_step)) + 1))
    times.update(input_events)
    times.update(spending_events)
    times.update(placement_events)
    times.update(completion_events)
    times.update(tech_completion_events)
    times.update(checkpoint_events)
    ordered_times = sorted(time for time in times if 0 <= time <= evidence.duration + 0.001)
    last_time = ordered_times[0]

    def process_interval(start: float, end: float) -> None:
        if end <= start:
            return
        dt = end - start
        active_by_player = defaultdict(lambda: {resource: 0.0 for resource in RESOURCE_KEYS})
        for assignment in list(assignments.values()):
            if assignment.state != "gathering" or assignment.family not in RESOURCE_KEYS:
                continue
            rate = assignment_rate(assignment, completed_techs[assignment.player])
            amount = rate * dt
            if amount <= 0:
                continue
            taken = 0.0
            if assignment.subtype == "farm" and assignment.farm_plot_id:
                taken, _ = farm_ledger.consume(
                    assignment.farm_plot_id,
                    amount,
                    balances[assignment.player],
                    assignment.player,
                    end,
                    completed_techs[assignment.player],
                    auto_reseed[assignment.player],
                    assignment.worker_id,
                )
            else:
                taken, _ = resource_ledger.consume(
                    assignment.family,
                    amount,
                    assignment.player,
                    end,
                    target_id=assignment.target_id,
                    position=assignment.position,
                    reason="worker_gather_cycle",
                )
            balances[assignment.player][assignment.family] += taken
            income_cumulative[assignment.player][assignment.family] += taken
            active_by_player[assignment.player][assignment.family] += max(taken, amount * 0.5)
            interval_activity[assignment.player][assignment.family] += max(taken, amount * 0.5)
            if assignment.position is not None:
                last_resource_position[assignment.player][assignment.family] = assignment.position
        for player in player_numbers:
            for resource in RESOURCE_KEYS:
                active_workers = sum(
                    1 for assignment in assignments.values()
                    if assignment.player == player and assignment.state == "gathering" and assignment.family == resource
                )
                carried[player][resource] = min(active_workers * 10.0, active_by_player[player][resource] * 0.35)

    def apply_spending(event: dict[str, Any]) -> None:
        player = event["player"]
        cost = event.get("cost", {})
        income = event.get("income", {})
        for resource in RESOURCE_KEYS:
            amount = float(cost.get(resource, 0.0))
            if amount <= 0:
                continue
            affordability_floor[player][resource] = max(affordability_floor[player][resource], amount)
            if balances[player][resource] + 0.001 < amount:
                gap = amount - balances[player][resource]
                balances[player][resource] += gap
                corrections_by_player[player].append({
                    "time": clean_number(event["time"]),
                    "resource": resource,
                    "amount": clean_number(gap),
                    "reason": f"resource-specific affordability for {event['kind']}: {event['name']}",
                    "source": "forward_filter_affordability_gap",
                    "confidence": "required",
                })
            balances[player][resource] -= amount
            spent_cumulative[player][resource] += amount
        for resource, amount in income.items():
            balances[player][resource] += float(amount)

    def process_placement(event: dict[str, Any]) -> None:
        player = event.get("player")
        position = numeric_position(event.get("position"))
        if not isinstance(player, int) or position is None:
            return
        bounds = placement_bounds(event)
        building = str(event.get("name") or "Building")
        resource_ledger.clear_for_building(bounds, event["time"], player, building)
        for worker_id, prior in list(assignments.items()):
            if prior.state != "gathering":
                continue
            target_node = resource_ledger.nodes.get(prior.target_id) if prior.target_id is not None else None
            target_position = target_node.position if target_node is not None else prior.position
            target_family = target_node.family if target_node is not None else prior.family
            overlaps = (
                resource_tile_overlaps_bounds(target_position, bounds)
                if target_family == "Wood"
                else position_in_bounds(target_position, bounds)
            )
            if not overlaps:
                continue
            replacement = Assignment(
                worker_id=worker_id,
                player=prior.player,
                state="uncertain",
                position=target_position,
                confidence="observed_spatial_constraint",
                reason=f"{building} placement invalidated the prior gather destination",
            )
            assignments[worker_id] = replacement
            update_worker_state(worker_history, replacement, event["time"])
        for source_id, point in list(tc_gather_points.items()):
            if position_in_bounds(point.get("position"), bounds):
                tc_gather_points.pop(source_id, None)
        if building != "Farm":
            return
        farm_ledger.ensure_generation(
            player,
            position,
            event["time"],
            "explicit_reseed" if event.get("kind") == "Reseed" else "explicit_build",
            completed_techs[player],
            auto_reseed[player],
            (),
            "observed",
        )

    def process_input(row: dict[str, Any], time: float) -> None:
        kind = row.get("type")
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        player = row.get("player")
        if kind == "Farm Autoqueue" and isinstance(player, int):
            auto_reseed[player] = "on"
            return
        if kind == "Fish Trap Autoqueue":
            return
        if kind == "Move":
            destination = event_position(row)
            if destination is not None:
                for selected_id in object_ids(payload):
                    node = resource_ledger.nodes.get(selected_id)
                    if node is not None and node.family == "Food" and node.subtype in {"sheep", "livestock", "herdable"}:
                        node.position = destination.copy()
        if kind in {"Gather", "Order"}:
            # Only Order rows whose target resolves to a resource are economic assignments.
            new_assignments = assignment_from_gather(row, evidence, farm_ledger, time)
            for assignment in new_assignments:
                assignments[assignment.worker_id] = assignment
                update_worker_state(worker_history, assignment, time)
            return
        if kind == "Gather Point":
            target_id = payload.get("target_id")
            source_ids = object_ids(payload)
            name = resource_name_from_target(row, evidence.catalog)
            family, subtype = resource_family(name)
            for source_id in source_ids:
                tc_gather_points[source_id] = {
                    "time": time,
                    "player": player,
                    "target_id": target_id if isinstance(target_id, int) else None,
                    "resource_name": name,
                    "family": family,
                    "subtype": subtype,
                    "position": event_position(row),
                }
            return
        if kind in {"Build", "Reseed"} and isinstance(player, int):
            name = payload.get("building") or row.get("param")
            workers = [worker for worker in object_ids(payload) if is_worker(worker, evidence.catalog)]
            position = event_position(row)
            if name == "Farm" and position is not None:
                farm_assignments = farm_ledger.assign_workers_to_farms(player, workers, position, time, limit_to_supported=True)
                for worker_id, plot_id in farm_assignments.items():
                    assignment = Assignment(
                        worker_id=worker_id,
                        player=player,
                        state="gathering",
                        family="Food",
                        subtype="farm",
                        farm_plot_id=plot_id,
                        position=position,
                        confidence="probable",
                        reason=f"{kind} Farm command supports farm work",
                    )
                    assignments[worker_id] = assignment
                    update_worker_state(worker_history, assignment, time)
            else:
                for worker_id in workers:
                    assignment = Assignment(
                        worker_id=worker_id,
                        player=player,
                        state="constructing",
                        position=position,
                        confidence="observed",
                        reason=f"{kind} command: {name}",
                    )
                    assignments[worker_id] = assignment
                    update_worker_state(worker_history, assignment, time)
            return
        if kind in {"Move", "Stop", "Garrison", "Ungarrison", "Target"} and isinstance(player, int):
            state = {
                "Move": "moving",
                "Stop": "idle",
                "Garrison": "garrisoned",
                "Ungarrison": "moving",
                "Target": "combat",
            }[kind]
            for worker_id in [worker for worker in object_ids(payload) if is_worker(worker, evidence.catalog)]:
                assignment = Assignment(
                    worker_id=worker_id,
                    player=player,
                    state=state,
                    position=event_position(row),
                    confidence="observed",
                    reason=f"{kind} command contradicts gathering",
                )
                assignments[worker_id] = assignment
                update_worker_state(worker_history, assignment, time)

    def process_completion(event: dict[str, Any]) -> None:
        if event.get("name") != "Villager":
            return
        player = event["player"]
        producer_id = event.get("producer_id")
        point = tc_gather_points.get(producer_id)
        if not point or point.get("player") != player or point.get("family") not in RESOURCE_KEYS:
            return
        count = event.get("count", 1)
        if not isinstance(count, int) or count <= 0:
            count = 1
        for offset in range(count):
            synthetic_id = f"p{player}:villager_from_{producer_id}:{event['time']:.3f}:{offset + 1}"
            if point["subtype"] == "farm":
                farm_assignments = farm_ledger.assign_workers_to_farms(player, [synthetic_id], point.get("position"), event["time"], limit_to_supported=True)
                plot_id = farm_assignments.get(synthetic_id)
                if not plot_id:
                    continue
            else:
                plot_id = None
            assignment = Assignment(
                worker_id=synthetic_id,
                player=player,
                state="gathering",
                family=point["family"],
                subtype=point["subtype"],
                target_id=point["target_id"],
                farm_plot_id=plot_id,
                position=point["position"],
                confidence="probable",
                reason="new Villager inherited exact producer Town Center gather point",
            )
            assignments[synthetic_id] = assignment
            update_worker_state(worker_history, assignment, event["time"])

    def sample_uncertainty_context(player: int, current_time: float, checkpoint: dict[str, Any] | None) -> dict[str, Any]:
        checkpoint_times = checkpoint_times_by_player.get(player, [])
        prior_checkpoints = [time for time in checkpoint_times if time <= current_time]
        future_checkpoints = [time for time in checkpoint_times if time >= current_time]
        active_assignments = [
            assignment for assignment in assignments.values()
            if assignment.player == player and assignment.state == "gathering"
        ]
        inferred = [assignment for assignment in active_assignments if assignment.confidence != "observed"]
        events_nearby = sum(1 for time in event_times_by_player.get(player, []) if abs(time - current_time) <= 60.0)
        unresolved = float(checkpoint.get("unresolved_residual", 0.0)) if checkpoint else 0.0
        recent_capacity_residuals = resource_ledger.capacity_residuals[-200:]
        unsupported_capacity = sum(
            abs(float(row.get("unallocated", 0.0)))
            for row in recent_capacity_residuals
            if row.get("player") == player and float(row.get("time", 0.0)) <= current_time
        )
        return {
            "seconds_since_checkpoint": current_time - max(prior_checkpoints) if prior_checkpoints else current_time,
            "seconds_to_checkpoint": min(future_checkpoints) - current_time if future_checkpoints else max(0.0, evidence.duration - current_time),
            "events_nearby": events_nearby,
            "unresolved_residual": abs(unresolved),
            "unsupported_capacity": unsupported_capacity,
            "inferred_assignment_ratio": (len(inferred) / len(active_assignments)) if active_assignments else 1.0,
            "explicit_worker_majority": bool(active_assignments and len(inferred) * 2 <= len(active_assignments)),
        }

    def record_event_state(current_time: float, phase: str, reason: str, players: Iterable[int] | None = None, checkpoint_by_player: dict[int, dict[str, Any]] | None = None) -> None:
        selected_players = list(players) if players is not None else player_numbers
        checkpoint_by_player = checkpoint_by_player or {}
        phase_order = {"pre_spend": 0, "post_event": 1}.get(phase, 1)
        for player in selected_players:
            checkpoint = checkpoint_by_player.get(player)
            state = {
                "time": clean_number(current_time),
                "phase": phase,
                "phase_order": phase_order,
                "player": player,
                "central": {
                    **clean_resources(balances[player]),
                    "Total": clean_number(total_resources(balances[player])),
                },
                "carried_resources": {
                    **clean_resources(carried[player]),
                    "Total": clean_number(total_resources(carried[player])),
                },
                "spending_cumulative": {
                    **clean_resources(spent_cumulative[player]),
                    "Total": clean_number(total_resources(spent_cumulative[player])),
                },
                "spending_events": [
                    {
                        "kind": event["kind"],
                        "name": event["name"],
                        "cost": clean_resources(event.get("cost", {})),
                        "source": event.get("source"),
                    }
                    for event in sorted(spending_events.get(current_time, []), key=lambda row: (row["player"], row["kind"], row["name"], row.get("economy_index", 0)))
                    if event["player"] == player
                ],
                "checkpoint": checkpoint,
                "last_resource_position": {
                    resource: clean_position(last_resource_position[player][resource])
                    for resource in RESOURCE_KEYS
                },
                "uncertainty_context": sample_uncertainty_context(player, current_time, checkpoint),
                "reason": reason,
            }
            rows = event_states[player]
            if not rows or rows[-1] != state:
                rows.append(state)

    for current_time in ordered_times:
        process_interval(last_time, current_time)
        for event in sorted(tech_completion_events.get(current_time, []), key=lambda row: (row["player"], row["name"])):
            completed_techs[event["player"]].add(event["name"])
        for event in sorted(placement_events.get(current_time, []), key=lambda row: (row["player"], row["kind"], row["name"], json.dumps(row.get("position"), sort_keys=True))):
            process_placement(event)
        for row in sorted(input_events.get(current_time, []), key=exact_sort_key):
            process_input(row, current_time)
        for event in sorted(completion_events.get(current_time, []), key=lambda row: (row["player"], row["name"], row.get("producer_id") or 0)):
            process_completion(event)
        if spending_events.get(current_time):
            spend_players = sorted({event["player"] for event in spending_events[current_time]})
            record_event_state(current_time, "pre_spend", "state immediately before order-time spending", spend_players)
        for event in sorted(spending_events.get(current_time, []), key=lambda row: (row["player"], row["kind"], row["name"])):
            apply_spending(event)
        checkpoint_by_player = {row["player"]: row for row in checkpoint_events.get(current_time, [])}
        for checkpoint in sorted(checkpoint_events.get(current_time, []), key=lambda row: row["player"]):
            player = checkpoint["player"]
            raw_total = total_resources(balances[player])
            observed = checkpoint["observed_total"]
            residual = observed - raw_total
            activity_weights = resource_weights_from_activity(interval_activity, player)
            if sum(activity_weights.values()) <= 0:
                activity_weights = fallback_resource_weights(player, evidence, current_time)
            proposed = allocate_residual_by_weights(residual, activity_weights, balances[player])
            positive = {resource: max(0.0, proposed[resource]) for resource in RESOURCE_KEYS}
            negative = {resource: min(0.0, proposed[resource]) for resource in RESOURCE_KEYS}
            allocated_positive, capacity_residual = resource_ledger.allocate_checkpoint_correction(
                player,
                current_time,
                positive,
                last_resource_position[player],
            )
            correction = {resource: allocated_positive[resource] + negative[resource] for resource in RESOURCE_KEYS}
            add_resources(balances[player], correction, 1.0)
            unresolved = residual - total_resources(correction)
            record = {
                "time": clean_number(current_time),
                "observed_total": clean_number(observed),
                "raw_prediction_total": clean_number(raw_total),
                "residual_before_correction": clean_number(residual),
                "correction": clean_resources(correction),
                "unresolved_residual": clean_number(unresolved),
                "weights": {resource: clean_number(activity_weights.get(resource, 0.0), 4) for resource in RESOURCE_KEYS},
                "capacity_residual": clean_resources(capacity_residual),
                "confidence": "aggregate_checkpoint_current_stockpile",
            }
            checkpoint_records[player].append(record)
            residuals.append({**record, "player": player})
            corrections_by_player[player].append({
                "time": clean_number(current_time),
                "amount": clean_number(total_resources(correction)),
                "by_resource": clean_resources(correction),
                "unresolved_residual": clean_number(unresolved),
                "reason": "aggregate checkpoint reconciliation",
                "source": "pass1_local_interval",
                "confidence": "bounded_inference",
            })
            interval_activity[player] = {resource: 0.0 for resource in RESOURCE_KEYS}
        post_checkpoint_by_player = {}
        for player in checkpoint_by_player:
            post_checkpoint_by_player[player] = checkpoint_records[player][-1]
        record_event_state(current_time, "post_event", "state after event-boundary spending/checkpoint processing", checkpoint_by_player=post_checkpoint_by_player)
        for player in player_numbers:
            checkpoint = None
            observed = None
            if player in checkpoint_by_player:
                latest = checkpoint_records[player][-1]
                checkpoint = latest
                observed = checkpoint_by_player[player]["observed_total"] - float(latest["unresolved_residual"])
            is_sample_time = (
                abs((current_time / sample_step) - round(current_time / sample_step)) <= 0.0001
                or current_time in checkpoint_events
                or current_time == evidence.duration
            )
            if is_sample_time:
                samples[player].append(sample_from_state(
                    current_time,
                    player,
                    balances[player],
                    carried[player],
                    spent_cumulative[player],
                    observed,
                    checkpoint,
                    affordability_floor[player],
                    "composition inferred from commands, capacities, spending, and local aggregate reconciliation",
                    sample_uncertainty_context(player, current_time, checkpoint),
                ))
        last_time = current_time

    return {
        "samples_by_player": {str(player): rows for player, rows in sorted(samples.items())},
        "event_states_by_player": {str(player): rows for player, rows in sorted(event_states.items())},
        "checkpoint_records": {str(player): rows for player, rows in sorted(checkpoint_records.items())},
        "corrections": {str(player): rows for player, rows in sorted(corrections_by_player.items())},
        "worker_state_timelines": {
            str(worker): rows for worker, rows in sorted(worker_history.items(), key=lambda item: str(item[0]))
            if len(rows) > 1 or (rows and rows[0]["state"] != "uncertain")
        },
        "income_cumulative": {
            str(player): clean_resources(values) for player, values in sorted(income_cumulative.items())
        },
        "residuals": residuals,
        "final_balances": {str(player): {**clean_resources(balances[player]), "Total": clean_number(total_resources(balances[player]))} for player in player_numbers},
    }


def pass2_requirement_at(pass2: dict[str, Any], player: str, time: float) -> dict[str, Any] | None:
    rows = pass2.get("requirements_series_by_player", {}).get(player, [])
    latest = None
    for row in rows:
        if float(row.get("time", 0.0)) <= time + 0.001:
            latest = row
        else:
            break
    return latest


def force_total(resources: dict[str, float], target_total: float) -> None:
    drift = target_total - total_resources(resources)
    if abs(drift) <= 0.001:
        return
    if drift > 0:
        resources["Food"] += drift
        return
    remaining = -drift
    for resource in sorted(RESOURCE_KEYS, key=lambda key: (-resources.get(key, 0.0), key)):
        take = min(remaining, max(0.0, resources.get(resource, 0.0)))
        resources[resource] -= take
        remaining -= take
        if remaining <= 0.001:
            break


def rebalance_for_requirements(
    central: dict[str, float],
    requirements: dict[str, float],
    fixed_total: float | None,
) -> tuple[dict[str, float], dict[str, float], dict[str, float]]:
    result = {resource: max(0.0, float(central.get(resource, 0.0))) for resource in RESOURCE_KEYS}
    if fixed_total is not None:
        force_total(result, fixed_total)
    adjustments = {resource: 0.0 for resource in RESOURCE_KEYS}
    unmet = {resource: 0.0 for resource in RESOURCE_KEYS}

    for resource in sorted(RESOURCE_KEYS, key=lambda key: (-requirements.get(key, 0.0), key)):
        need = max(0.0, float(requirements.get(resource, 0.0)) - result[resource])
        if need <= 0.001:
            continue
        donors = sorted(
            (other for other in RESOURCE_KEYS if other != resource),
            key=lambda key: (-(result[key] - max(0.0, requirements.get(key, 0.0))), key),
        )
        for donor in donors:
            donor_surplus = max(0.0, result[donor] - max(0.0, requirements.get(donor, 0.0)))
            take = min(need, donor_surplus)
            if take <= 0.001:
                continue
            result[donor] -= take
            result[resource] += take
            adjustments[donor] -= take
            adjustments[resource] += take
            need -= take
            if need <= 0.001:
                break
        if need > 0.001:
            unmet[resource] += need
    if fixed_total is not None:
        force_total(result, fixed_total)
    return result, adjustments, unmet


def recompute_sample_ranges(sample: dict[str, Any], requirements: dict[str, float], checkpoint_total: float | None) -> None:
    central = {resource: float(sample["central"][resource]) for resource in RESOURCE_KEYS}
    central_total = total_resources(central)
    context = dict(sample.get("uncertainty_context", {}))
    context["pass2_adjustment_abs"] = sum(abs(float(value)) for value in sample.get("pass3_adjustment", {}).values())
    context["unmet_pass2_requirement"] = sum(float(value) for value in sample.get("pass3_unmet_requirement", {}).values())
    spread = uncertainty_width(central_total, context)
    states = likely_states(central, central_total, spread)
    sample["central"] = {**clean_resources(central), "Total": clean_number(central_total)}
    sample["likely_states"] = states
    sample["likely_ranges"] = ranges_from_states(states)
    sample["feasible_ranges"] = feasible_ranges(central, checkpoint_total, requirements, spread * 2)
    sample["uncertainty_context"] = {
        **{key: clean_number(value) if finite_number(value) else value for key, value in sorted(context.items())},
        "scenario_band_width": clean_number(spread),
        "band_method": "deterministic evidence-responsive correlated scenarios",
    }


def fallback_event_states_from_samples(pass1: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    states: dict[str, list[dict[str, Any]]] = {}
    for player, samples in pass1.get("samples_by_player", {}).items():
        rows = []
        for sample in samples:
            rows.append({
                "time": sample["time"],
                "phase": "post_event",
                "phase_order": 1,
                "player": int(player),
                "central": sample["central"],
                "carried_resources": sample.get("carried_resources", {}),
                "spending_cumulative": sample.get("spending_cumulative", {}),
                "spending_events": [],
                "checkpoint": sample.get("checkpoint"),
                "uncertainty_context": sample.get("uncertainty_context", {}),
                "reason": "fallback event state synthesized from display sample",
            })
        states[player] = rows
    return states


def capacity_budget_from_pass2(pass2: dict[str, Any]) -> dict[str, float]:
    rows = pass2.get("node_capacity_requirements", [])
    if not rows:
        return {resource: math.inf for resource in RESOURCE_KEYS}
    budget = {resource: 0.0 for resource in RESOURCE_KEYS}
    for row in rows:
        resource = row.get("resource")
        if resource not in RESOURCE_KEYS:
            continue
        capacity = float(row.get("observed_map_capacity", 0.0) or 0.0)
        already_required = float(row.get("minimum_collection_after_starts", 0.0) or 0.0)
        budget[resource] = max(0.0, capacity - already_required)
    return budget


def apply_capacity_budget(
    revised: dict[str, float],
    adjustment: dict[str, float],
    capacity_remaining: dict[str, float],
    time: float,
    player: str,
    spatial_ledger: ResourceLedger | None = None,
    positions: dict[str, dict[str, float] | None] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, float]]:
    allocations: list[dict[str, Any]] = []
    residual = {resource: 0.0 for resource in RESOURCE_KEYS}
    for resource in RESOURCE_KEYS:
        positive = max(0.0, adjustment.get(resource, 0.0))
        if positive <= 0.001:
            continue
        available = capacity_remaining.get(resource, math.inf)
        allocated = min(positive, available)
        spatial_details: list[dict[str, Any]] = []
        if allocated > 0.001 and spatial_ledger is not None:
            position = (positions or {}).get(resource)
            if position is None:
                allocated = 0.0
            else:
                taken, details = spatial_ledger.consume(
                    resource,
                    allocated,
                    int(player),
                    time,
                    position=position,
                    reason="pass3_positive_spatial_capacity_allocation",
                )
                allocated = taken
                spatial_details = details
        if math.isfinite(available):
            capacity_remaining[resource] = max(0.0, available - allocated)
        if allocated > 0.001:
            allocation = {
                "time": clean_number(time),
                "player": int(player),
                "resource": resource,
                "amount": clean_number(allocated),
                "remaining_pass3_capacity_budget": clean_number(capacity_remaining.get(resource, 0.0)) if math.isfinite(capacity_remaining.get(resource, math.inf)) else "unbounded",
                "source": "pass3_positive_composition_adjustment_capacity_budget",
                "spatial": spatial_ledger is not None,
            }
            if spatial_details:
                allocation["nodes"] = [
                    {
                        **detail,
                        "cluster_id": spatial_ledger.nodes[detail["node_id"]].cluster_id if detail.get("node_id") in spatial_ledger.nodes else None,
                    }
                    for detail in spatial_details
                ]
            allocations.append(allocation)
        excess = positive - allocated
        if excess <= 0.001:
            continue
        revised[resource] = max(0.0, revised[resource] - excess)
        adjustment[resource] -= excess
        residual[resource] += excess
        donors = sorted(
            (other for other in RESOURCE_KEYS if adjustment.get(other, 0.0) < -0.001),
            key=lambda key: (adjustment[key], key),
        )
        if donors:
            donor = donors[0]
            revised[donor] += excess
            adjustment[donor] += excess
    return allocations, residual


def checkpoint_reconciliation_adjustment(
    central: dict[str, float],
    target_total: float,
    checkpoint: dict[str, Any],
    hard_requirements: dict[str, float],
    soft_requirements: dict[str, float],
) -> dict[str, float]:
    delta = target_total - total_resources(central)
    adjustment = {resource: 0.0 for resource in RESOURCE_KEYS}
    if abs(delta) <= 0.001:
        return adjustment
    if delta > 0:
        remaining = delta
        for resource in sorted(RESOURCE_KEYS, key=lambda key: (-(hard_requirements.get(key, 0.0) - central.get(key, 0.0)), key)):
            deficit = max(0.0, hard_requirements.get(resource, 0.0) - central.get(resource, 0.0))
            add = min(remaining, deficit)
            if add > 0.001:
                adjustment[resource] += add
                remaining -= add
            if remaining <= 0.001:
                return adjustment
        activity_weights = checkpoint.get("weights", {}) if isinstance(checkpoint.get("weights"), dict) else {}
        continuity_total = max(0.001, total_resources(central))
        raw_weights = {}
        for resource in RESOURCE_KEYS:
            continuity = max(0.0, central.get(resource, 0.0)) / continuity_total
            activity = max(0.0, float(activity_weights.get(resource, 0.0) or 0.0))
            pressure = max(0.0, soft_requirements.get(resource, 0.0))
            raw_weights[resource] = continuity * 0.50 + activity * 0.35 + pressure * 0.15 / max(1.0, total_resources(soft_requirements))
        weight_total = sum(raw_weights.values())
        if weight_total <= 0:
            raw_weights = {resource: 1.0 for resource in RESOURCE_KEYS}
            weight_total = len(RESOURCE_KEYS)
        for resource in RESOURCE_KEYS:
            adjustment[resource] += remaining * raw_weights[resource] / weight_total
        drift = delta - total_resources(adjustment)
        adjustment["Food"] += drift
        return adjustment

    remaining = -delta
    donors = sorted(
        RESOURCE_KEYS,
        key=lambda key: (-(central.get(key, 0.0) - hard_requirements.get(key, 0.0)), key),
    )
    for resource in donors:
        removable = max(0.0, central.get(resource, 0.0) - hard_requirements.get(resource, 0.0))
        take = min(remaining, removable)
        if take > 0.001:
            adjustment[resource] -= take
            remaining -= take
        if remaining <= 0.001:
            break
    return adjustment


def farm_requirements_by_player(pass2: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in pass2.get("farm_generation_requirements", []):
        player = row.get("player")
        if isinstance(player, int):
            grouped[str(player)].append(row)
    for rows in grouped.values():
        rows.sort(key=lambda row: (float(row.get("first_explicit_farm_time", row.get("time", 0.0)) or 0.0), json.dumps(row, sort_keys=True)))
    return grouped


def coalesce_residual_episodes(rows: list[dict[str, Any]], max_gap: float = 90.0) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    expanded = []
    for row in rows:
        resources = row.get("resources") or row.get("unmet_requirement") or row.get("capacity_residual") or {}
        if resources:
            for resource in RESOURCE_KEYS:
                amount = float(resources.get(resource, 0.0) or 0.0)
                if abs(amount) > 0.001:
                    expanded.append({**row, "resource": resource, "amount": amount})
        else:
            amount = float(row.get("unresolved_residual", row.get("amount", 0.0)) or 0.0)
            if abs(amount) > 0.001:
                expanded.append({**row, "resource": row.get("resource", "Total"), "amount": amount})

    expanded.sort(key=lambda row: (
        str(row.get("category", row.get("kind", "residual"))),
        str(row.get("player", "global")),
        str(row.get("resource", "Total")),
        float(row.get("time", row.get("start", 0.0)) or 0.0),
    ))
    episodes: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for row in expanded:
        category = str(row.get("category", row.get("kind", "residual")))
        player = row.get("player", "global")
        resource = row.get("resource", "Total")
        time = float(row.get("time", row.get("start", 0.0)) or 0.0)
        amount = abs(float(row.get("amount", 0.0)))
        key = (category, str(player), resource)
        if current is None or current["_key"] != key or time - float(current["end_time"]) > max_gap:
            if current is not None:
                episodes.append({name: value for name, value in current.items() if name != "_key"})
            current = {
                "_key": key,
                "category": category,
                "player": player,
                "resource": resource,
                "start_time": clean_number(time),
                "end_time": clean_number(time),
                "event_count": 1,
                "absolute_magnitude_sum": amount,
                "absolute_magnitude_max": amount,
                "examples": [row.get("reason") or row.get("kind") or category],
            }
        else:
            current["end_time"] = clean_number(time)
            current["event_count"] += 1
            current["absolute_magnitude_sum"] += amount
            current["absolute_magnitude_max"] = max(float(current["absolute_magnitude_max"]), amount)
            reason = row.get("reason") or row.get("kind") or category
            if reason not in current["examples"] and len(current["examples"]) < 3:
                current["examples"].append(reason)
    if current is not None:
        episodes.append({name: value for name, value in current.items() if name != "_key"})
    for episode in episodes:
        episode["absolute_magnitude_sum"] = clean_number(episode["absolute_magnitude_sum"])
        episode["absolute_magnitude_max"] = clean_number(episode["absolute_magnitude_max"])

    summary_map: dict[tuple[str, str, str], dict[str, Any]] = {}
    for episode in episodes:
        key = (str(episode["category"]), str(episode["player"]), str(episode["resource"]))
        item = summary_map.setdefault(key, {
            "category": episode["category"],
            "player": episode["player"],
            "resource": episode["resource"],
            "episode_count": 0,
            "event_count": 0,
            "absolute_magnitude_sum": 0.0,
            "absolute_magnitude_max": 0.0,
        })
        item["episode_count"] += 1
        item["event_count"] += int(episode["event_count"])
        item["absolute_magnitude_sum"] += float(episode["absolute_magnitude_sum"])
        item["absolute_magnitude_max"] = max(float(item["absolute_magnitude_max"]), float(episode["absolute_magnitude_max"]))
    summary = []
    for item in summary_map.values():
        item["absolute_magnitude_sum"] = clean_number(item["absolute_magnitude_sum"])
        item["absolute_magnitude_max"] = clean_number(item["absolute_magnitude_max"])
        summary.append(item)
    summary.sort(key=lambda row: (str(row["category"]), str(row["player"]), str(row["resource"])))
    return episodes, summary


def synthesize_final(evidence: RawEvidence, pass1: dict[str, Any], pass2: dict[str, Any], spatial_ledger: ResourceLedger | None = None) -> dict[str, Any]:
    final_samples_by_player: dict[str, list[dict[str, Any]]] = {}
    final_event_states_by_player: dict[str, list[dict[str, Any]]] = {}
    adjustments_by_player: dict[str, list[dict[str, Any]]] = defaultdict(list)
    unmet_requirements: list[dict[str, Any]] = []
    residual_rows: list[dict[str, Any]] = []
    capacity_allocations: list[dict[str, Any]] = []
    capacity_remaining = capacity_budget_from_pass2(pass2)
    farm_rows_by_player = farm_requirements_by_player(pass2)
    farm_synthesis_events: list[dict[str, Any]] = []
    farm_unmet: list[dict[str, Any]] = []

    event_states = pass1.get("event_states_by_player") or fallback_event_states_from_samples(pass1)
    for player, states in event_states.items():
        ordered_states = sorted(states, key=lambda row: (float(row["time"]), int(row.get("phase_order", 1)), row.get("phase", "")))
        final_events: list[dict[str, Any]] = []
        pass1_previous: dict[str, float] | None = None
        final_current: dict[str, float] | None = None
        processed_farm_rows: set[int] = set()
        for state in ordered_states:
            time = float(state["time"])
            pass1_current = {resource: float(state["central"].get(resource, 0.0)) for resource in RESOURCE_KEYS}
            if final_current is None:
                final_current = dict(pass1_current)
                transition = {resource: 0.0 for resource in RESOURCE_KEYS}
            else:
                transition = {resource: pass1_current[resource] - (pass1_previous or pass1_current)[resource] for resource in RESOURCE_KEYS}
                intended_total = total_resources(final_current) + total_resources(transition)
                add_resources(final_current, transition, 1.0)
                for resource in RESOURCE_KEYS:
                    if final_current[resource] < -0.001:
                        final_current[resource] = 0.0
                target_total = max(0.0, intended_total)
                force_total(final_current, target_total)
                if intended_total < -0.001:
                    residual_rows.append({
                        "time": clean_number(time),
                        "player": int(player),
                        "category": "pass3_transition_aggregate_insufficient",
                        "resources": {"Food": -intended_total},
                        "reason": "Pass 1 aggregate transition exceeded the entire available final aggregate; central estimate stayed nonnegative.",
                    })
            pass1_previous = pass1_current

            for row_index, farm_req in enumerate(farm_rows_by_player.get(player, [])):
                if row_index in processed_farm_rows:
                    continue
                req_time = float(farm_req.get("first_explicit_farm_time", farm_req.get("time", 0.0)) or 0.0)
                if time + 0.001 < req_time:
                    continue
                gap = int(farm_req.get("unsupported_generation_gap", 0) or 0)
                supportable = int(farm_req.get("supportable_inferred_generations", 0) or (1 if farm_req.get("supportable") else 0))
                to_create = min(gap, supportable)
                if to_create > 0:
                    wood_cost = float(farm_req.get("wood_cost", FARM_WOOD_COST) or FARM_WOOD_COST) * to_create
                    food_capacity = float(farm_req.get("food_capacity", FARM_FOOD_CAPACITY["none"]) or FARM_FOOD_CAPACITY["none"]) * to_create
                    if final_current["Wood"] + 0.001 >= wood_cost:
                        final_current["Wood"] -= wood_cost
                        farm_synthesis_events.append({
                            "time": clean_number(time),
                            "player": int(player),
                            "kind": "pass3_supported_inferred_farm_generation",
                            "generations": to_create,
                            "wood_cost": clean_number(wood_cost),
                            "food_capacity": clean_number(food_capacity),
                            "source": "pass2_farm_generation_requirement_with_support",
                        })
                    else:
                        farm_unmet.append({
                            "time": clean_number(time),
                            "player": int(player),
                            "category": "pass3_farm_generation_unmet",
                            "resources": {"Wood": wood_cost - final_current["Wood"]},
                            "reason": "Supported inferred farm generation lacked wood at plausible seed time.",
                        })
                missing = max(0, gap - to_create)
                if missing > 0:
                    farm_unmet.append({
                        "time": clean_number(time),
                        "player": int(player),
                        "category": "pass3_farm_generation_unmet",
                        "resources": {"Food": missing * FARM_FOOD_CAPACITY["none"]},
                        "reason": "Backward food demand required farm generations without supporting reseed/plot/auto-reseed evidence.",
                    })
                processed_farm_rows.add(row_index)

            requirement_row = pass2_requirement_at(pass2, player, time)
            soft_requirements = {
                resource: float((requirement_row or {}).get("minimum_balance", {}).get(resource, 0.0))
                for resource in RESOURCE_KEYS
            }
            requirements = {resource: 0.0 for resource in RESOURCE_KEYS}
            if requirement_row and requirement_row.get("constraint_class") == "hard_affordability":
                requirements = dict(soft_requirements)
            if state.get("phase") == "pre_spend":
                spend_cost = {resource: 0.0 for resource in RESOURCE_KEYS}
                for event in state.get("spending_events", []):
                    add_resources(spend_cost, event.get("cost", {}), 1.0)
                for resource in RESOURCE_KEYS:
                    requirements[resource] = max(requirements[resource], spend_cost[resource])
            checkpoint = state.get("checkpoint")
            checkpoint_total = None
            unattributed_checkpoint = None
            if checkpoint:
                checkpoint_total = float(checkpoint["observed_total"])
                source_attribution_adjustment = checkpoint_reconciliation_adjustment(
                    pass1_current,
                    checkpoint_total,
                    checkpoint,
                    requirements,
                    soft_requirements,
                )
                checkpoint_adjustment = checkpoint_reconciliation_adjustment(
                    final_current,
                    checkpoint_total,
                    checkpoint,
                    requirements,
                    soft_requirements,
                )
                if abs(total_resources(checkpoint_adjustment)) > 0.001:
                    add_resources(final_current, checkpoint_adjustment, 1.0)
                force_total(final_current, checkpoint_total)
                if abs(total_resources(source_attribution_adjustment)) > 0.001:
                    unattributed_checkpoint = {
                        "time": clean_number(time),
                        "player": int(player),
                        "observed_total": clean_number(checkpoint_total),
                        "pass1_raw_prediction_total": checkpoint.get("raw_prediction_total"),
                        "pass1_unresolved_source_residual": checkpoint.get("unresolved_residual"),
                        "total": clean_number(total_resources(source_attribution_adjustment)),
                        "by_resource_hypothesis": clean_resources(source_attribution_adjustment),
                        "pass3_sequential_checkpoint_adjustment": clean_resources(checkpoint_adjustment),
                        "reason": "known aggregate checkpoint stockpile with unresolved physical source/composition attribution",
                    }
                    residual_rows.append({
                        "time": clean_number(time),
                        "player": int(player),
                        "category": "aggregate_checkpoint_source_attribution_residual",
                        "resource": "Total",
                        "amount": clean_number(abs(total_resources(source_attribution_adjustment))),
                        "reason": "Known checkpoint aggregate forced into final stockpile; physical provenance remains unattributed.",
                    })
            fixed_total = checkpoint_total if checkpoint_total is not None else total_resources(final_current)
            revised, adjustment, unmet = rebalance_for_requirements(final_current, requirements, fixed_total)
            allocations, capacity_residual = apply_capacity_budget(
                revised,
                adjustment,
                capacity_remaining,
                time,
                player,
                spatial_ledger,
                state.get("last_resource_position", {}),
            )
            capacity_allocations.extend(allocations)
            for resource, amount in capacity_residual.items():
                if amount > 0.001:
                    unmet[resource] += amount
                    residual_rows.append({
                        "time": clean_number(time),
                        "player": int(player),
                        "category": "pass3_capacity_budget_unmet",
                        "resources": {resource: amount},
                        "reason": "Pass 3 positive resource adjustment exceeded shared plausible capacity budget.",
                    })
            final_current = revised
            changed = any(abs(value) > 0.001 for value in adjustment.values())
            if changed:
                adjustments_by_player[player].append({
                    "time": clean_number(time),
                    "phase": state.get("phase", "post_event"),
                    "by_resource": clean_resources(adjustment),
                    "unmet_requirement": clean_resources(unmet),
                    "reason": "Pass 3 sequentially revised the carried-forward state to satisfy backward requirements where supported.",
                })
            if any(value > 0.001 for value in unmet.values()):
                row = {
                    "time": clean_number(time),
                    "player": int(player),
                    "category": "pass3_unmet_requirement",
                    "unmet_requirement": clean_resources(unmet),
                    "fixed_aggregate_total": clean_number(fixed_total),
                    "reason": "Sequential final state could not satisfy Pass 2 resource-specific minimum inside aggregate/capacity constraints.",
                }
                unmet_requirements.append(row)
                residual_rows.append(row)
            event_out = {
                "time": clean_number(time),
                "phase": state.get("phase", "post_event"),
                "phase_order": state.get("phase_order", 1),
                "player": int(player),
                "central": {**clean_resources(final_current), "Total": clean_number(total_resources(final_current))},
                "pass1_central": {**clean_resources(pass1_current), "Total": clean_number(total_resources(pass1_current))},
                "pass1_transition": clean_resources(transition),
                "pass2_requirement": {
                    "time": requirement_row.get("time") if requirement_row else None,
                    "minimum_balance": clean_resources(requirements),
                    "minimum_total": clean_number(total_resources(requirements)),
                    "constraint_class": "hard_affordability" if any(requirements.values()) else "none",
                    "source": requirement_row.get("source") if requirement_row else "no active hard requirement",
                },
                "pass2_soft_pressure": {
                    "time": requirement_row.get("time") if requirement_row else None,
                    "minimum_balance": clean_resources(soft_requirements),
                    "minimum_total": clean_number(total_resources(soft_requirements)),
                    "constraint_class": requirement_row.get("constraint_class") if requirement_row else None,
                    "coverage": requirement_row.get("coverage") if requirement_row else None,
                },
                "pass3_adjustment": clean_resources(adjustment),
                "pass3_unmet_requirement": clean_resources(unmet),
                "unattributed_checkpoint_reconciliation": unattributed_checkpoint,
                "checkpoint": checkpoint,
                "capacity_allocations": allocations,
                "reason": "sequential Pass 3 event-state synthesis",
                "uncertainty_context": state.get("uncertainty_context", {}),
            }
            if checkpoint:
                checkpoint["pass3_central_total"] = event_out["central"]["Total"]
                checkpoint["pass3_requirement_total"] = clean_number(total_resources(requirements))
            final_events.append(event_out)
        final_event_states_by_player[player] = final_events

    for row in farm_unmet:
        residual_rows.append(row)

    for player, samples in pass1["samples_by_player"].items():
        final_events = final_event_states_by_player.get(player, [])
        final_rows = []
        for original in samples:
            sample = json.loads(json.dumps(original, sort_keys=True))
            time = float(sample["time"])
            event = None
            for candidate in final_events:
                if float(candidate["time"]) <= time + 0.001:
                    event = candidate
                else:
                    break
            if event is None:
                continue
            requirements = {
                resource: float(event.get("pass2_requirement", {}).get("minimum_balance", {}).get(resource, 0.0))
                for resource in RESOURCE_KEYS
            }
            checkpoint_total = None
            checkpoint = sample.get("checkpoint")
            if checkpoint:
                checkpoint_total = float(checkpoint["observed_total"])
            sample["central"] = event["central"]
            sample["pass1_central"] = original["central"]
            sample["pass2_requirement"] = event["pass2_requirement"]
            sample["pass2_soft_pressure"] = event.get("pass2_soft_pressure", {})
            sample["pass3_adjustment"] = event["pass3_adjustment"]
            sample["pass3_unmet_requirement"] = event["pass3_unmet_requirement"]
            sample["unattributed_checkpoint_reconciliation"] = event.get("unattributed_checkpoint_reconciliation")
            sample["pass3_event_phase"] = event["phase"]
            sample["pass3_event_time"] = event["time"]
            sample["capacity_allocations"] = event.get("capacity_allocations", [])
            sample.setdefault("uncertainty_context", {})
            sample["uncertainty_context"]["soft_backward_pressure_total"] = event.get("pass2_soft_pressure", {}).get("minimum_total", 0)
            recompute_sample_ranges(sample, requirements, checkpoint_total)
            sample["confidence"]["reason"] = (
                sample["confidence"]["reason"]
                + "; final Pass 3 central state is downsampled from sequential event-state synthesis"
            )
            final_rows.append(sample)
        final_samples_by_player[player] = final_rows

    for row in pass1.get("residuals", []):
        residual_rows.append({
            "time": row.get("time", 0),
            "player": row.get("player", "global"),
            "category": "pass1_checkpoint_unresolved_residual",
            "unresolved_residual": row.get("unresolved_residual", 0),
            "reason": "Pass 1 checkpoint correction could not be fully reconciled with bounded capacity.",
        })
    for row in pass2.get("infeasible_or_residual_constraints", []):
        residual_rows.append({
            "time": row.get("time", 0),
            "player": row.get("player", "global"),
            "category": row.get("kind", "pass2_residual_constraint"),
            "resource": row.get("resource", "Total"),
            "amount": row.get("unresolved_residual", row.get("unsupported_generation_gap", 0)),
            "reason": row.get("kind", "Pass 2 residual constraint"),
        })
    residual_episodes, residual_summary = coalesce_residual_episodes(residual_rows)

    final_balances = {}
    for player, rows in final_samples_by_player.items():
        last = rows[-1] if rows else None
        final_balances[player] = last["central"] if last else pass1["final_balances"].get(player, {})

    return {
        "principle": (
            "Pass 3 is a sequential synthesis over compact Pass 1 event states. It applies each Pass 1 transition "
            "to the previous final state, enforces Pass 2 requirements at pre-spend and post-event boundaries, "
            "carries the resulting composition forward, and down-samples the final trajectory for display."
        ),
        "samples_by_player": final_samples_by_player,
        "event_states_by_player": final_event_states_by_player,
        "checkpoint_records": pass1["checkpoint_records"],
        "corrections": {
            player: pass1["corrections"].get(player, []) + adjustments_by_player.get(player, [])
            for player in sorted(set(pass1["corrections"]) | set(adjustments_by_player))
        },
        "worker_state_timelines": pass1["worker_state_timelines"],
        "income_cumulative": pass1["income_cumulative"],
        "final_balances": final_balances,
        "pass2_constraints_used": {
            "affordability_requirement_rows_applied": sum(len(rows) for rows in pass2.get("requirements_series_by_player", {}).values()),
            "pre_spend_event_states_checked": sum(1 for rows in final_event_states_by_player.values() for row in rows if row.get("phase") == "pre_spend"),
            "capacity_budget_resources_applied": len([resource for resource, value in capacity_budget_from_pass2(pass2).items() if value != math.inf]),
            "capacity_allocation_events": len(capacity_allocations),
            "farm_generation_requirements_processed": len(pass2.get("farm_generation_requirements", [])),
            "supported_inferred_farm_generations": sum(int(row.get("generations", 0)) for row in farm_synthesis_events),
        },
        "pass3_adjustments_by_player": {player: rows for player, rows in sorted(adjustments_by_player.items())},
        "pass3_capacity_allocations": capacity_allocations,
        "pass3_capacity_budget_remaining": {
            resource: clean_number(value) if math.isfinite(value) else "unbounded"
            for resource, value in sorted(capacity_remaining.items())
        },
        "pass3_farm_synthesis_events": farm_synthesis_events,
        "pass3_farm_unmet": farm_unmet,
        "pass3_unmet_requirements": unmet_requirements,
        "residual_episodes": residual_episodes,
        "residual_summary": residual_summary,
        "irreducible_residuals": residual_episodes,
        "raw_residual_rows": residual_rows,
    }


def methodology(evidence: RawEvidence, observation_semantics: dict[str, Any]) -> dict[str, Any]:
    return {
        "determinism": "No generated wall-clock timestamps are emitted. Inputs are normalized and sorted by timestamp plus stable semantic keys.",
        "observation_semantics": observation_semantics,
        "passes": {
            "pass1_causal_forward_filter": (
                "Processes commands, estimated completions, spending, technologies, farms, worker assignments, "
                "resource-node capacity, building-footprint clearance constraints, and aggregate checkpoints in timestamp order. "
                "A building placement closes overlapping gather assignments and resource nodes without crediting removed capacity as income. Checkpoint reconciliation "
                "uses only evidence at or before the checkpoint and records raw prediction, residual, correction, "
                "and unresolved residual separately."
            ),
            "pass2_independent_backward_requirements": (
                "Computes affordability and farm-generation requirements from raw events and rule tables only; "
                "it does not accept Pass 1 balances, corrections, or inferred composition."
            ),
            "pass3_constrained_forward_synthesis": (
                "Runs sequentially over compact Pass 1 event states. Each Pass 1 transition is applied to the prior "
                "final state, Pass 2 affordability is checked at pre-spend boundaries, aggregate checkpoints bind "
                "the total, positive resource reallocations are bounded by a shared capacity budget, and unsupported "
                "farm/capacity conflicts are coalesced as residual episodes."
            ),
        },
        "rule_coverage": {
            "costs": "economy.json spending is used as the canonical deduplicated base-cost contract and is charged at input/order time.",
            "research_timing": "Pinned ResearchTime values set technology effect start times.",
            "farm_capacity": "Farm generation capacity is split by technologies completed before seed/reseed: base, Horse Collar, Heavy Plow, Crop Rotation.",
            "market": "Buy/Sell commands are preserved as exposed evidence but not charged in V1 because economy.json excludes them from its spending contract; aggregate residuals preserve their unexplained effects.",
            "resource_capacity": "Gold, stone, berries, herdables, wild animals, bounded tree frontiers, and farms have finite central capacities.",
            "building_clearance": "An accepted placement footprint is hard spatial evidence that overlapping gather targets and modeled resource nodes are no longer available; removed node capacity is not counted as gathered income.",
        },
        "unsupported_mechanics": [
            "Exact AoE II pathfinding and bumping are not simulated; straight-line/bounded-efficiency assumptions are used.",
            "Civilization discounts, team bonuses, unique economic bonuses, relic/trade/special income, repair costs, refunds from cancels/deletes, tribute, and conversion ownership changes are only represented when explicit evidence is exposed and otherwise remain residual risk.",
            "The replay exposes farm autoqueue enabled at match start, but not a later toggle state; unsupported depletion/reseed cases are reported instead of inventing unlimited farms.",
            "The field total_resources does not expose resource composition or carried worker payloads.",
            "Untouched transitive forests are not fully instantiated in the output; only bounded tree frontiers around observed tree commands are modeled as nodes.",
        ],
        "deduplication": evidence.deduplication,
        "economy_count_reconciliation": {
            "conclusion": "resource reconstruction uses economy.json's deduplicated economic contract for spending/completions/placements",
            "spending_events_used": evidence.counts.get("spending_events"),
            "economy_json_spending_events": evidence.counts.get("economy_json_spending_events"),
            "unit_completions_used": evidence.counts.get("unit_completions"),
            "economy_json_unit_completions": evidence.counts.get("economy_json_unit_completions"),
            "market_rows_preserved_not_charged": evidence.counts.get("market_events_preserved_not_charged"),
            "cancellations_preserved_without_refund_model": evidence.counts.get("cancellation_or_delete_events_preserved"),
            "reason": (
                "The earlier reconstruction rebuilt costs from broader replay inputs and added market rows, producing "
                "935 spending and 815 completion rows. That double-counted outside the existing economy.json contract. "
                "V1 now uses the 715 spending rows and 713 producer-linked completions from economy.json, while preserving "
                "market/cancel evidence separately and leaving unsupported refunds/conversions as residual risk."
            ),
        },
        "uncertainty": "Ranges are deterministic evidence-responsive likely/feasible envelopes, not calibrated statistical confidence intervals.",
    }


def validate_result(result: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if result.get("schema") != SCHEMA:
        errors.append("schema mismatch")
    for player, samples in result.get("players", {}).items():
        times = [sample.get("time") for sample in samples.get("samples", [])]
        if times != sorted(times):
            errors.append(f"player {player} samples are not sorted")
        for index, sample in enumerate(samples.get("samples", [])):
            central = sample.get("central", {})
            if any(not finite_number(central.get(resource)) for resource in (*RESOURCE_KEYS, "Total")):
                errors.append(f"player {player} sample {index} has nonfinite central resources")
                continue
            if any(float(central[resource]) < -0.001 for resource in RESOURCE_KEYS):
                errors.append(f"player {player} sample {index} has negative central resource")
            summed = sum(float(central[resource]) for resource in RESOURCE_KEYS)
            if abs(summed - float(central["Total"])) > 0.01:
                errors.append(f"player {player} sample {index} central total does not match resource sum")
            checkpoint = sample.get("checkpoint")
            if checkpoint:
                expected_total = float(checkpoint.get("observed_total", 0.0))
                if abs(float(central["Total"]) - expected_total) > 0.01:
                    errors.append(f"player {player} sample {index} checkpoint central total does not equal observed aggregate")
            for range_name in ("likely_ranges", "feasible_ranges"):
                ranges = sample.get(range_name, {})
                for resource in (*RESOURCE_KEYS, "Total"):
                    bounds = ranges.get(resource, {})
                    if not finite_number(bounds.get("low")) or not finite_number(bounds.get("high")):
                        errors.append(f"player {player} sample {index} {range_name} {resource} bounds are nonfinite")
                        continue
                    if float(bounds["low"]) - float(central[resource]) > 0.01 or float(central[resource]) - float(bounds["high"]) > 0.01:
                        errors.append(f"player {player} sample {index} {range_name} {resource} does not contain central")
            for state in sample.get("likely_states", []):
                state_total = sum(float(state["resources"][resource]) for resource in RESOURCE_KEYS)
                if abs(state_total - float(state["total"])) > 0.01:
                    errors.append(f"player {player} sample {index} likely state total mismatch")
                if abs(state_total - float(central["Total"])) > 0.01:
                    errors.append(f"player {player} sample {index} likely state does not satisfy central aggregate total")
            requirement = sample.get("pass2_requirement", {}).get("minimum_balance", {})
            unmet = sample.get("pass3_unmet_requirement", {})
            for resource in RESOURCE_KEYS:
                required = float(requirement.get(resource, 0.0) or 0.0)
                unresolved = float(unmet.get(resource, 0.0) or 0.0)
                if float(central[resource]) + unresolved + 0.01 < required:
                    errors.append(f"player {player} sample {index} violates Pass 3 {resource} requirement without residual")
    for node in result.get("resource_nodes", []):
        remaining = node.get("remaining", {}).get("central")
        starting = node.get("starting_capacity")
        if not finite_number(remaining) or not finite_number(starting):
            errors.append(f"node {node.get('instance_id')} has nonfinite capacity")
        elif float(remaining) < -0.001 or float(remaining) - float(starting) > 0.001:
            errors.append(f"node {node.get('instance_id')} has overdrawn central capacity")
    for worker, rows in result.get("worker_resource_attribution", {}).items():
        times = [row.get("time") for row in rows]
        if times != sorted(times):
            errors.append(f"worker {worker} timeline is not sorted")
        seen = defaultdict(set)
        for row in rows:
            seen[row.get("time")].add(row.get("state"))
        for time, states in seen.items():
            incompatible = states.intersection({"gathering", "constructing", "moving", "garrisoned", "combat"})
            if len(incompatible) > 1:
                errors.append(f"worker {worker} has simultaneous incompatible states at {time}")
    pass2 = result.get("passes", {}).get("pass2_backward_requirements", {})
    if not pass2.get("does_not_accept_pass1"):
        errors.append("Pass 2 API accepts pass1-derived input")
    pass3 = result.get("passes", {}).get("pass3_final_synthesis", {})
    for row in pass3.get("pass3_capacity_allocations", []):
        amount = row.get("amount")
        if row.get("resource") not in RESOURCE_KEYS or not finite_number(amount) or float(amount) < -0.001:
            errors.append("Pass 3 capacity allocation has invalid resource or amount")
    if not pass3.get("residual_episodes"):
        errors.append("Pass 3 residuals are not coalesced into episodes")
    return errors


def build_result(game: dict[str, Any], lifetimes: dict[str, Any], economy: dict[str, Any], reference: dict[str, Any], sources: dict[str, str], sample_step: float = 30.0) -> dict[str, Any]:
    rules = RuleTables.from_reference(reference)
    evidence = build_raw_evidence(game, lifetimes, economy, rules)
    observation_semantics = audit_observation_semantics(evidence)
    resource_ledger = ResourceLedger.from_game(game, evidence.inputs)
    farm_ledger = FarmLedger()
    pass1 = run_forward_filter(evidence, rules, resource_ledger, farm_ledger, sample_step=sample_step)
    pass2 = run_backward_requirements(evidence, rules)
    pass3 = synthesize_final(evidence, pass1, pass2, resource_ledger)
    players_out = {}
    for player in evidence.players:
        number = player["number"]
        players_out[str(number)] = {
            "number": number,
            "name": player.get("name"),
            "color": player.get("color"),
            "civilization": player.get("civilization"),
            "samples": pass3["samples_by_player"].get(str(number), []),
            "checkpoints": pass3["checkpoint_records"].get(str(number), []),
            "corrections": pass3["corrections"].get(str(number), []),
            "income_cumulative": pass3["income_cumulative"].get(str(number), {}),
            "final_balance": pass3["final_balances"].get(str(number), {}),
        }
    result = {
        "schema": SCHEMA,
        "version": 1,
        "source": sources,
        "resource_keys": list(RESOURCE_KEYS),
        "methodology": methodology(evidence, observation_semantics),
        "counts": {
            **evidence.counts,
            "resource_nodes_modeled": len(resource_ledger.nodes),
            "omitted_untouched_tree_nodes": resource_ledger.omitted_tree_count,
            "farm_plots": len(farm_ledger.plots),
            "farm_events": len(farm_ledger.events),
            "building_resource_clearances": len(resource_ledger.building_clearance_events),
            "pass3_adjustments": sum(len(rows) for rows in pass3.get("pass3_adjustments_by_player", {}).values()),
            "pass3_unmet_requirements": len(pass3.get("pass3_unmet_requirements", [])),
            "pass3_event_states": sum(len(rows) for rows in pass3.get("event_states_by_player", {}).values()),
            "pass3_capacity_allocations": len(pass3.get("pass3_capacity_allocations", [])),
            "pass3_residual_episodes": len(pass3.get("residual_episodes", [])),
            "aggregate_checkpoint_source_attribution_episodes": sum(1 for row in pass3.get("residual_episodes", []) if row.get("category") == "aggregate_checkpoint_source_attribution_residual"),
            "hard_affordability_residual_episodes": sum(1 for row in pass3.get("residual_episodes", []) if row.get("category") == "pass3_unmet_requirement"),
            "spatial_capacity_residual_episodes": sum(1 for row in pass3.get("residual_episodes", []) if row.get("category") == "pass3_capacity_budget_unmet"),
            "raw_residual_rows": len(pass3.get("raw_residual_rows", [])),
            "irreducible_residuals": len(pass3["irreducible_residuals"]),
        },
        "passes": {
            "pass1_forward_filter": {
                "principle": "Original causal forward filter output preserved compactly for audit before Pass 3 backward synthesis.",
                "display_sample_count_by_player": {player: len(rows) for player, rows in sorted(pass1["samples_by_player"].items())},
                "event_state_count_by_player": {player: len(rows) for player, rows in sorted(pass1.get("event_states_by_player", {}).items())},
                "display_sample_pass1_central_embedded_in_final_samples": True,
                "correction_count": sum(len(rows) for rows in pass1["corrections"].values()),
                "checkpoint_count": sum(len(rows) for rows in pass1["checkpoint_records"].values()),
                "checkpoint_records": pass1["checkpoint_records"],
                "final_balances": pass1["final_balances"],
            },
            "pass2_backward_requirements": pass2,
            "pass3_final_synthesis": {
                "principle": pass3["principle"],
                "pass2_constraints_used": pass3["pass2_constraints_used"],
                "adjustment_count": sum(len(rows) for rows in pass3.get("pass3_adjustments_by_player", {}).values()),
                "event_state_count_by_player": {player: len(rows) for player, rows in sorted(pass3.get("event_states_by_player", {}).items())},
                "pass3_adjustments_by_player": pass3.get("pass3_adjustments_by_player", {}),
                "pass3_capacity_allocations": pass3.get("pass3_capacity_allocations", [])[:400],
                "pass3_capacity_budget_remaining": pass3.get("pass3_capacity_budget_remaining", {}),
                "pass3_farm_synthesis_events": pass3.get("pass3_farm_synthesis_events", []),
                "pass3_farm_unmet": pass3.get("pass3_farm_unmet", [])[:200],
                "pass3_unmet_requirements": pass3.get("pass3_unmet_requirements", [])[:200],
                "residual_episodes": pass3.get("residual_episodes", [])[:400],
                "residual_summary": pass3.get("residual_summary", []),
                "raw_residual_row_count": len(pass3.get("raw_residual_rows", [])),
                "irreducible_residuals": pass3["irreducible_residuals"][:200],
            },
        },
        "players": players_out,
        "technology_research_starts": evidence.tech_starts,
        "technology_completions": evidence.tech_completions,
        "worker_resource_attribution": pass3["worker_state_timelines"],
        "resource_nodes": resource_ledger.export_nodes(),
        "resource_clusters": resource_ledger.export_clusters(),
        "building_resource_clearances": resource_ledger.building_clearance_events,
        "farm_plots": farm_ledger.export(),
        "farm_events": farm_ledger.events,
        "final_synthesis_capacity_allocations": pass3.get("pass3_capacity_allocations", []),
        "final_synthesis_farm_events": pass3.get("pass3_farm_synthesis_events", []),
        "residual_episodes": pass3.get("residual_episodes", []),
        "residual_summary": pass3.get("residual_summary", []),
        "diagnostics": {
            "resource_capacity_residuals": resource_ledger.capacity_residuals[:200],
            "node_transfer_events": resource_ledger.transfer_events[:200],
            "building_resource_clearances": resource_ledger.building_clearance_events[:200],
            "invariant_violations": [],
            "economy_json_schema_seen": economy.get("schema"),
            "limitations_residual": "See methodology.unsupported_mechanics and pass3_final_synthesis.irreducible_residuals.",
        },
        "indexes": {
            "sample_times_by_player": {
                player: [sample["time"] for sample in rows.get("samples", [])]
                for player, rows in players_out.items()
            },
            "resource_node_ids": [node["instance_id"] for node in resource_ledger.export_nodes()],
            "farm_plot_ids": [plot["plot_id"] for plot in farm_ledger.export()],
        },
    }
    errors = validate_result(result)
    result["diagnostics"]["invariant_violations"] = errors
    if errors:
        raise ValueError("resource reconstruction validation failed:\n- " + "\n- ".join(errors))
    return result


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(data, indent=2, sort_keys=True, ensure_ascii=True, separators=(",", ": ")) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
        os.chmod(path, 0o644)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game", type=Path, default=DEFAULT_GAME)
    parser.add_argument("--lifetimes", type=Path, default=DEFAULT_LIFETIMES)
    parser.add_argument("--economy", type=Path, default=DEFAULT_ECONOMY)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--sample-step", type=float, default=30.0)
    args = parser.parse_args()

    game_path = args.game.resolve()
    lifetimes_path = args.lifetimes.resolve()
    economy_path = args.economy.resolve()
    reference_path = args.reference.resolve()
    output_path = args.output.resolve()
    if args.sample_step <= 0 or not math.isfinite(args.sample_step):
        raise ValueError("--sample-step must be a positive finite number")

    game = json.loads(game_path.read_text(encoding="utf-8"))
    lifetimes = json.loads(lifetimes_path.read_text(encoding="utf-8"))
    economy = json.loads(economy_path.read_text(encoding="utf-8"))
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    sources = {
        "game_json": str(game_path),
        "game_json_sha256": sha256_path(game_path),
        "lifetimes_json": str(lifetimes_path),
        "lifetimes_json_sha256": sha256_path(lifetimes_path),
        "economy_json": str(economy_path),
        "economy_json_sha256": sha256_path(economy_path),
        "reference_json": str(reference_path),
        "reference_json_sha256": sha256_path(reference_path),
        "source_recording_sha256": game.get("source_recording", {}).get("sha256"),
    }
    result = build_result(game, lifetimes, economy, reference, sources, sample_step=args.sample_step)
    atomic_write_json(output_path, result)
    written = json.loads(output_path.read_text(encoding="utf-8"))
    errors = validate_result(written)
    if errors:
        raise ValueError("written artifact validation failed:\n- " + "\n- ".join(errors))
    digest = sha256_path(output_path)
    print(f"generator: {Path(__file__).resolve()}")
    print(f"output: {output_path}")
    print(f"schema: {written['schema']}")
    print(f"players: {len(written['players'])}")
    print(f"samples: {sum(len(player['samples']) for player in written['players'].values())}")
    print(f"resource nodes: {len(written['resource_nodes'])}")
    print(f"farm plots: {len(written['farm_plots'])}")
    print(f"pass3 event states: {written['counts']['pass3_event_states']}")
    print(f"residual episodes: {written['counts']['pass3_residual_episodes']}")
    print(f"irreducible residuals: {written['counts']['irreducible_residuals']}")
    print(f"validation: sorted timelines; finite values; nonnegative central balances; capacity and correlated-range checks passed")
    print(f"pass2 api: {written['passes']['pass2_backward_requirements']['api_signature']}")
    print(f"sha256: {digest}")
    print(f"mode: {oct(output_path.stat().st_mode & 0o777)}")


if __name__ == "__main__":
    main()
