#!/usr/bin/env python3
"""Build a conservative, best-effort AoE II lifecycle/event index.

The recording is a command stream, not a sequence of full world snapshots. This
analyzer therefore records direct observations and bounded inferences with an
explicit confidence level. It never promotes a queue command to a confirmed
spawn or a final command to a confirmed death.
"""

from __future__ import annotations

import argparse
import bisect
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

FOREST_TERRAINS = {48, 89, 112}
VALID_INSTANCE_MAX = 1_000_000
MAP_EVENT_TYPES = {
    "Build": "build",
    "Reseed": "build",
    "Move": "move",
    "Gather": "gather",
    "Target": "target",
    "Order": "order",
    "Attack Ground": "attack",
    "Wall": "build",
}


def seconds(value: str) -> float:
    hours, minutes, secs = value.split(":")
    return int(hours) * 3600 + int(minutes) * 60 + float(secs)


def clock(value: float) -> str:
    milliseconds = round(value * 1000)
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours}:{minutes:02d}:{secs:02d}.{millis:03d}"


def valid_instance(value) -> bool:
    return isinstance(value, int) and 0 < value < VALID_INSTANCE_MAX


def position_of(row):
    position = row.get("position")
    if not position:
        return None
    x = position.get("x")
    y = position.get("y")
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        return None
    if not math.isfinite(x) or not math.isfinite(y) or x < 0 or y < 0:
        return None
    return {"x": round(float(x), 4), "y": round(float(y), 4)}


def event(time, kind, label, *, player=None, confidence="observed", position=None,
          object_ids=None, target_id=None, detail=None):
    result = {
        "time": round(time, 3),
        "kind": kind,
        "label": label,
        "confidence": confidence,
    }
    if player is not None:
        result["player"] = player
    if position is not None:
        result["position"] = position
    if object_ids:
        result["object_ids"] = object_ids
    if target_id is not None:
        result["target_id"] = target_id
    if detail:
        result["detail"] = detail
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("game_json", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    game = json.loads(args.game_json.read_text(encoding="utf-8"))
    match = game["match"]
    duration = float(game["summary"]["duration_seconds"])
    players = {player["number"]: player for player in match["players"]}

    objects = {}

    def ensure_object(instance_id):
        return objects.setdefault(instance_id, {
            "instance_id": instance_id,
            "owner": None,
            "name": None,
            "name_confidence": None,
            "initial": False,
            "start_position": None,
            "first_observed": None,
            "last_observed": None,
            "first_action": None,
            "last_action": None,
            "explicit_delete": None,
            "combat_targeted": [],
        })

    resource_objects = {}
    gaia_names = {}
    for obj in match["gaia"]:
        instance_id = obj["instance_id"]
        gaia_names[instance_id] = obj.get("name")
        row = ensure_object(instance_id)
        row.update({
            "owner": 0,
            "name": obj.get("name"),
            "name_confidence": "observed",
            "initial": True,
            "start_position": obj.get("position"),
            "first_observed": 0.0,
            "last_observed": 0.0,
            "first_action": "initial",
            "last_action": "initial",
        })
        if obj.get("name") in {"Gold Mine", "Stone Mine"}:
            resource_objects[instance_id] = row

    for player in match["players"]:
        for obj in player["objects"]:
            row = ensure_object(obj["instance_id"])
            row.update({
                "owner": player["number"],
                "name": obj.get("name"),
                "name_confidence": "observed" if obj.get("name") else None,
                "initial": True,
                "start_position": obj.get("position"),
                "first_observed": 0.0,
                "last_observed": 0.0,
                "first_action": "initial",
                "last_action": "initial",
            })

    actions = sorted(match["actions"], key=lambda row: seconds(row["timestamp"]))
    first_observation_groups = []
    action_rows = []

    # First pass: establish ownership and observation bounds from command actors.
    for action in actions:
        time = seconds(action["timestamp"])
        player = action.get("player")
        payload = action.get("payload", {})
        position = position_of(action)
        newly_observed = []
        actor_ids = [oid for oid in payload.get("object_ids", []) if valid_instance(oid)]
        target_id = payload.get("target_id")

        for instance_id in actor_ids:
            row = ensure_object(instance_id)
            if row["owner"] is None and player in players:
                row["owner"] = player
            if row["first_observed"] is None:
                row["first_observed"] = round(time, 3)
                row["first_action"] = action["type"]
                newly_observed.append(instance_id)
            row["last_observed"] = round(time, 3)
            row["last_action"] = action["type"]

        if valid_instance(target_id):
            row = ensure_object(target_id)
            if row["first_observed"] is None:
                row["first_observed"] = round(time, 3)
                row["first_action"] = f"target of {action['type']}"
                newly_observed.append(target_id)
            row["last_observed"] = round(time, 3)
            row["last_action"] = f"target of {action['type']}"

        if action["type"] == "DELETE":
            for instance_id in actor_ids:
                ensure_object(instance_id)["explicit_delete"] = round(time, 3)

        action_rows.append((time, action, actor_ids, target_id, position))
        if newly_observed:
            first_observation_groups.append((time, player, action["type"], newly_observed, position))

    # Second pass: identify cross-player target orders after actor ownership is known.
    for time, action, actor_ids, target_id, position in action_rows:
        if not valid_instance(target_id) or target_id not in objects:
            continue
        player = action.get("player")
        target = objects[target_id]
        if player in players and target["owner"] in players and player != target["owner"]:
            target["combat_targeted"].append(round(time, 3))

    inputs = sorted(match["inputs"], key=lambda row: seconds(row["timestamp"]))

    # Infer useful object labels only from strong behavioral evidence.
    build_positions = {}
    for item in inputs:
        time = seconds(item["timestamp"])
        kind = item.get("type")
        payload = item.get("payload", {})
        actor_ids = [oid for oid in payload.get("object_ids", []) if valid_instance(oid)]
        position = position_of(item)
        if kind in {"Build", "Reseed", "Wall"}:
            for instance_id in actor_ids:
                row = ensure_object(instance_id)
                if not row["name"]:
                    row["name"] = "Villager"
                    row["name_confidence"] = "inferred from construction command"
            if position:
                build_positions[(round(position["x"], 3), round(position["y"], 3))] = {
                    "time": time,
                    "name": item.get("param") or payload.get("building") or kind,
                }
        elif kind == "Gather" and item.get("param") in {"Gold Mine", "Stone Mine"}:
            for instance_id in actor_ids:
                row = ensure_object(instance_id)
                if not row["name"]:
                    row["name"] = "Villager"
                    row["name_confidence"] = "inferred from mining command"
        elif kind == "De Autoscout":
            for instance_id in actor_ids:
                row = ensure_object(instance_id)
                if not row["name"]:
                    row["name"] = "Scout Cavalry"
                    row["name_confidence"] = "inferred from auto-scout command"
        elif kind in {"Queue", "Research", "Buy", "Sell"}:
            for instance_id in actor_ids:
                row = ensure_object(instance_id)
                if not row["name"]:
                    if kind in {"Buy", "Sell"}:
                        label = "Market"
                    elif kind == "Research":
                        label = "Research building"
                    else:
                        label = "Production building"
                    row["name"] = label
                    row["name_confidence"] = f"inferred from {kind.lower()} command"
        elif kind == "Target" and position:
            target_id = payload.get("target_id")
            built = build_positions.get((round(position["x"], 3), round(position["y"], 3)))
            if valid_instance(target_id) and built and built["time"] <= time:
                row = ensure_object(target_id)
                if not row["name"]:
                    row["name"] = item.get("param") or built["name"]
                    row["name_confidence"] = "inferred from build position and later target"

    lifecycle_events = []
    map_events = []

    for time, player, action_type, ids, position in first_observation_groups:
        owner_text = players.get(player, {}).get("name", f"Player {player}")
        actor_word = "object" if len(ids) == 1 else "objects"
        lifecycle_events.append(event(
            time,
            "first_observed",
            f"{len(ids)} new {actor_word} first observed for {owner_text}",
            player=player,
            confidence="observed alive by this time",
            position=position,
            object_ids=ids,
            detail=f"First command evidence: {action_type}.",
        ))

    # Compact repeated queue clicks into one visible event per second/unit/player.
    last_queue_key = None
    last_queue_time = -999.0
    for item in inputs:
        time = seconds(item["timestamp"])
        kind = item.get("type")
        player = item.get("player")
        payload = item.get("payload", {})
        position = position_of(item)
        actor_ids = [oid for oid in payload.get("object_ids", []) if valid_instance(oid)]
        target_id = payload.get("target_id") if valid_instance(payload.get("target_id")) else None

        if kind == "Queue":
            unit = item.get("param") or payload.get("unit") or "unit"
            key = (player, unit, tuple(actor_ids))
            if key == last_queue_key and time - last_queue_time <= 1.0:
                last_queue_time = time
                continue
            last_queue_key = key
            last_queue_time = time
            lifecycle_events.append(event(
                time, "queue", f"Queue command: {unit}", player=player,
                confidence="observed command; production not confirmed",
                object_ids=actor_ids,
            ))
        elif kind in {"Build", "Reseed", "Wall"}:
            building = item.get("param") or payload.get("building") or kind
            label = f"{kind} command: {building}"
            lifecycle_events.append(event(
                time, "build", label, player=player,
                confidence="observed command; completion not confirmed",
                position=position, object_ids=actor_ids,
            ))
        elif kind == "Research":
            technology = item.get("param") or payload.get("technology") or "technology"
            lifecycle_events.append(event(
                time, "research", f"Research command: {technology}", player=player,
                confidence="observed command; completion not confirmed",
                object_ids=actor_ids,
            ))
        elif kind == "Delete":
            lifecycle_events.append(event(
                time, "delete", f"Explicitly deleted {len(actor_ids)} object(s)", player=player,
                confidence="confirmed terminal command", object_ids=actor_ids,
            ))
        elif kind == "Resign":
            lifecycle_events.append(event(
                time, "resign", "Resigned", player=player,
                confidence="confirmed",
            ))

        if kind in MAP_EVENT_TYPES and position:
            param = item.get("param")
            label = kind + (f": {param}" if param else "")
            map_events.append(event(
                time, MAP_EVENT_TYPES[kind], label, player=player,
                confidence="observed command destination",
                position=position, object_ids=actor_ids, target_id=target_id,
            ))

    # Resource depletion: a later move/build directly on a mined node is evidence
    # of passability. Require it to occur after that node's final gather command.
    gather_times = defaultdict(list)
    for item in inputs:
        if item.get("type") != "Gather" or item.get("param") not in {"Gold Mine", "Stone Mine"}:
            continue
        target_id = item.get("payload", {}).get("target_id")
        if target_id in resource_objects:
            gather_times[target_id].append(seconds(item["timestamp"]))

    resource_tiles = defaultdict(list)
    for instance_id, row in resource_objects.items():
        pos = row["start_position"]
        resource_tiles[(math.floor(pos["x"]), math.floor(pos["y"]))].append(instance_id)

    depletion_candidates = {}
    for item in inputs:
        if item.get("type") not in {"Move", "Build", "Reseed", "Wall"}:
            continue
        position = position_of(item)
        if not position:
            continue
        time = seconds(item["timestamp"])
        tile = (math.floor(position["x"]), math.floor(position["y"]))
        for instance_id in resource_tiles.get(tile, []):
            gathers = gather_times.get(instance_id, [])
            if not gathers or time <= gathers[-1]:
                continue
            confidence = "probable" if item.get("type") in {"Build", "Reseed", "Wall"} else "possible"
            candidate = depletion_candidates.get(instance_id)
            if candidate is None or time < candidate["time"] or confidence == "probable" and candidate["confidence"] == "possible":
                resource = resource_objects[instance_id]
                depletion_candidates[instance_id] = event(
                    time, "resource_depletion",
                    f"{resource['name']} may be depleted; {item['type'].lower()} command crossed its tile",
                    player=item.get("player"), confidence=confidence,
                    position=resource["start_position"], object_ids=[instance_id],
                    detail=f"Last direct gather command was at {gathers[-1]:.3f}s.",
                )

    inferred_depletions = sorted(depletion_candidates.values(), key=lambda row: row["time"])
    lifecycle_events.extend(inferred_depletions)

    # Forest clearing: construction on forest is probable; repeated move destinations
    # on the same forest tile are only possible evidence because a blocked click may be
    # clamped by the game engine.
    tile_terrain = {
        (int(tile["position"]["x"]), int(tile["position"]["y"])): tile["terrain"]
        for tile in match["map"]["tiles"]
    }
    forest_builds = {}
    forest_moves = defaultdict(list)
    for item in inputs:
        position = position_of(item)
        if not position:
            continue
        tile = (math.floor(position["x"]), math.floor(position["y"]))
        if tile_terrain.get(tile) not in FOREST_TERRAINS:
            continue
        time = seconds(item["timestamp"])
        if item.get("type") in {"Build", "Reseed", "Wall"}:
            forest_builds.setdefault(tile, (time, item))
        elif item.get("type") == "Move":
            forest_moves[tile].append((time, item))

    inferred_clearings = []
    for tile, (time, item) in forest_builds.items():
        inferred_clearings.append(event(
            time, "forest_clearing",
            "Forest tile probably cleared before construction",
            player=item.get("player"), confidence="probable",
            position={"x": tile[0] + 0.5, "y": tile[1] + 0.5},
            detail=f"Terrain {tile_terrain[tile]}; {item['type']} command on this tile.",
        ))
    for tile, moves in forest_moves.items():
        if tile in forest_builds or len(moves) < 2:
            continue
        first_time, first_item = moves[0]
        inferred_clearings.append(event(
            first_time, "forest_clearing",
            "Forest tile may have become passable",
            player=first_item.get("player"), confidence="possible",
            position={"x": tile[0] + 0.5, "y": tile[1] + 0.5},
            detail=f"Terrain {tile_terrain[tile]}; {len(moves)} move destinations crossed this tile.",
        ))
    inferred_clearings.sort(key=lambda row: row["time"])
    lifecycle_events.extend(inferred_clearings)

    # Low-confidence loss windows: cross-player targeting followed by the object's
    # final observation and a synchronized aggregate object-count drop within 60s.
    timeseries = {}
    for player in match["players"]:
        rows = sorted(
            (seconds(row["timestamp"]), row["total_objects"])
            for row in player["timeseries"]
        )
        timeseries[player["number"]] = rows

    inferred_losses = []
    for instance_id, row in objects.items():
        if row["owner"] not in players or row["explicit_delete"] is not None:
            continue
        if not row["combat_targeted"] or row["last_observed"] is None:
            continue
        last = row["last_observed"]
        recent_target = max((t for t in row["combat_targeted"] if t <= last), default=None)
        if recent_target is None or last - recent_target > 90 or duration - last < 30:
            continue
        series = timeseries.get(row["owner"], [])
        if len(series) < 2:
            continue
        times = [point[0] for point in series]
        index = bisect.bisect_right(times, last) - 1
        if index < 0:
            continue
        baseline = series[index][1]
        drop = next((point for point in series[index + 1:] if point[0] <= last + 60 and point[1] < baseline), None)
        if not drop:
            continue
        label = row["name"] or f"Object {instance_id}"
        loss = event(
            drop[0], "possible_loss",
            f"{label} may have been lost between {clock(last)} and {clock(drop[0])}",
            player=row["owner"], confidence="possible",
            position=None, object_ids=[instance_id],
            detail="Last observed after enemy targeting; aggregate object count then decreased. Identity is not confirmed.",
        )
        inferred_losses.append(loss)
        row["possible_loss"] = {"after": round(last, 3), "before": round(drop[0], 3)}

    lifecycle_events.extend(inferred_losses)
    lifecycle_events.sort(key=lambda row: (row["time"], row["kind"], row["label"]))
    map_events.sort(key=lambda row: row["time"])

    object_rows = []
    for instance_id, row in sorted(objects.items()):
        if row["owner"] == 0 and instance_id not in resource_objects:
            continue
        if row["owner"] is None and not row["initial"]:
            continue
        clean = {key: value for key, value in row.items() if value not in (None, [], False)}
        if clean.get("combat_targeted"):
            clean["combat_targeted"] = clean["combat_targeted"][-5:]
        object_rows.append(clean)

    counts = {
        "indexed_objects": len(object_rows),
        "newly_observed_objects": sum(not row.get("initial", False) for row in object_rows),
        "named_or_inferred_objects": sum(bool(row.get("name")) for row in object_rows),
        "explicit_deletions": sum(row.get("explicit_delete") is not None for row in object_rows),
        "possible_combat_losses": len(inferred_losses),
        "possible_resource_depletions": len(inferred_depletions),
        "possible_forest_clearings": len(inferred_clearings),
        "map_events": len(map_events),
        "lifecycle_events": len(lifecycle_events),
    }

    output = {
        "schema": "aoe2-best-effort-lifetimes/v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "source_recording_sha256": game["source_recording"]["sha256"],
        "duration_seconds": duration,
        "method": {
            "principle": "Direct commands are observations; births, losses, and depletion remain bounded inferences unless explicitly encoded.",
            "confidence": ["observed", "confirmed", "probable", "possible"],
            "caveats": [
                "Queue commands do not confirm production completion.",
                "Command positions are destinations, not continuously sampled unit positions.",
                "Aggregate object-count changes do not identify which object disappeared.",
                "Move commands into forest may be blocked or clamped; repeated destinations are only possible clearing evidence.",
            ],
        },
        "players": [
            {
                "number": player["number"],
                "name": player["name"],
                "color": player["color"],
                "civilization": player["civilization"],
                "start_position": player["position"],
            }
            for player in match["players"]
        ],
        "counts": counts,
        "objects": object_rows,
        "map_events": map_events,
        "lifecycle_events": lifecycle_events,
        "inferred_depletions": inferred_depletions,
        "inferred_clearings": inferred_clearings,
        "inferred_losses": inferred_losses,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, separators=(",", ":"), ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "counts": counts}, indent=2))


if __name__ == "__main__":
    main()
