#!/usr/bin/env python3
"""Generate a compact, best-effort AoE II economy index from parsed inputs.

Queue rows are production intent, not confirmed spawns. Resource costs and map
footprints are likewise estimates. The output preserves these limitations in
its methodology metadata.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tempfile
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

REFERENCE_COMMIT = "b9d494df6921d4080df69b22f9dbb7a4d1dcd9f0"
REFERENCE_URL = (
    "https://raw.githubusercontent.com/SiegeEngineers/aoe2techtree/"
    f"{REFERENCE_COMMIT}/data/data.json"
)
DEFAULT_GAME = Path("game.json")
DEFAULT_OUTPUT = Path("economy.json")
RESOURCE_KEYS = ("Food", "Wood", "Gold", "Stone")
INPUT_KINDS = {"Queue", "Build", "Reseed", "Wall", "Research"}


def seconds(value: str) -> float:
    """Convert the parser's H:MM:SS.ffffff clock to seconds."""
    hours, minutes, secs = value.split(":")
    result = int(hours) * 3600 + int(minutes) * 60 + float(secs)
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"invalid nonnegative timestamp: {value!r}")
    return round(result, 3)


def numeric_position(value: Any) -> dict[str, float | int] | None:
    if not isinstance(value, dict):
        return None
    x, y = value.get("x"), value.get("y")
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        return None
    if isinstance(x, bool) or isinstance(y, bool):
        return None
    if not math.isfinite(x) or not math.isfinite(y):
        return None

    def clean(number: int | float) -> float | int:
        number = round(float(number), 4)
        return int(number) if number.is_integer() else number

    return {"x": clean(x), "y": clean(y)}


def object_ids(payload: dict[str, Any]) -> tuple[int, ...]:
    values = payload.get("object_ids", [])
    if not isinstance(values, list):
        return ()
    return tuple(sorted({value for value in values if isinstance(value, int) and value > 0}))


def semantic_key(row: dict[str, Any]) -> tuple[Any, ...]:
    """Identity used to collapse parser repeats while retaining placements."""
    kind = row.get("type")
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    player = row.get("player")
    producers = object_ids(payload)
    if kind == "Queue":
        return (
            kind,
            player,
            payload.get("unit_id"),
            payload.get("unit") or row.get("param"),
            producers,
            payload.get("amount"),
        )
    if kind in {"Build", "Reseed", "Wall"}:
        position = numeric_position(row.get("position"))
        start = None if position is None else (position["x"], position["y"])
        end = (payload.get("x_end"), payload.get("y_end")) if kind == "Wall" else None
        return (
            kind,
            player,
            payload.get("building_id"),
            payload.get("building") or row.get("param"),
            producers,
            start,
            end,
        )
    if kind == "Research":
        return (
            kind,
            player,
            payload.get("technology_id"),
            payload.get("technology") or row.get("param"),
            producers,
        )
    return (kind, player, json.dumps(payload, sort_keys=True, separators=(",", ":")))


def deduplicate(rows: Iterable[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    """Collapse semantic repeats whose adjacent timestamps are at most 1 second apart."""
    ordered = sorted(rows, key=lambda row: (seconds(row["timestamp"]), semantic_key(row)))
    latest: dict[tuple[Any, ...], float] = {}
    kept: list[dict[str, Any]] = []
    duplicates = 0
    for row in ordered:
        time = seconds(row["timestamp"])
        key = semantic_key(row)
        prior = latest.get(key)
        latest[key] = time
        if prior is not None and time - prior <= 1.0:
            duplicates += 1
            continue
        kept.append(row)
    return kept, duplicates


def reference_bytes(path: Path | None) -> tuple[bytes, str]:
    if path is not None:
        return path.read_bytes(), str(path.resolve())
    request = urllib.request.Request(REFERENCE_URL, headers={"User-Agent": "aoe-economy-index/1"})
    with urllib.request.urlopen(request, timeout=60) as response:
        return response.read(), REFERENCE_URL


def normalized_cost(raw: Any, multiplier: int = 1) -> dict[str, int | float]:
    if not isinstance(raw, dict) or not isinstance(multiplier, int) or multiplier < 0:
        return {}
    result: dict[str, int | float] = {}
    for resource in RESOURCE_KEYS:
        value = raw.get(resource)
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            continue
        total = float(value) * multiplier
        if not math.isfinite(total) or total <= 0:
            continue
        result[resource] = int(total) if total.is_integer() else round(total, 4)
    return result


def reference_entry(table: dict[str, Any], entity_id: Any) -> dict[str, Any] | None:
    if not isinstance(entity_id, int):
        return None
    value = table.get(str(entity_id))
    return value if isinstance(value, dict) else None


def research_entry(data: dict[str, Any], technology_id: Any) -> tuple[dict[str, Any] | None, str | None]:
    entry = reference_entry(data.get("Tech", {}), technology_id)
    if entry is not None:
        return entry, "Tech"
    if isinstance(technology_id, int):
        upgrades = data.get("unit_upgrades", {})
        if isinstance(upgrades, dict):
            matches = [value for value in upgrades.values() if isinstance(value, dict) and value.get("ID") == technology_id]
            if matches:
                matches.sort(key=lambda value: (str(value.get("internal_name", "")), json.dumps(value, sort_keys=True)))
                return matches[0], "unit_upgrades"
    return None, None


def footprint(name: str, position: dict[str, float | int], end_position: dict[str, float | int] | None) -> dict[str, Any]:
    """Return best-effort occupied AoE grid tiles, never sprite dimensions."""
    lowered = name.casefold().replace("-", " ")
    orientation = None
    if "wonder" in lowered or "feitoria" in lowered:
        width, height = 5, 5
    elif any(token in lowered for token in ("town center", "castle", "market")):
        width, height = 4, 4
    elif "gate" in lowered:
        width, height = 4, 1
        if end_position is not None:
            dx = abs(float(end_position["x"]) - float(position["x"]))
            dy = abs(float(end_position["y"]) - float(position["y"]))
            if dy > dx:
                width, height, orientation = 1, 4, "vertical"
            elif dx > dy:
                orientation = "horizontal"
            else:
                orientation = "diagonal_or_unknown"
        else:
            orientation = "unknown"
    elif "house" in lowered or "donjon" in lowered:
        width, height = 2, 2
    elif any(token in lowered for token in ("wall", "tower", "outpost")):
        width, height = 1, 1
    else:
        # Farms, camps, docks, monasteries, universities, blacksmiths, and
        # common military/economic production buildings use this approximation.
        width, height = 3, 3

    result: dict[str, Any] = {
        "tile_width": width,
        "tile_height": height,
        "source": "best_effort_aoe_grid_table_not_sprite_dimensions",
        "confidence": "best_effort",
    }
    if orientation is not None:
        result["orientation"] = orientation
    return result


def build_index(game: dict[str, Any], reference: dict[str, Any], reference_source: str, reference_sha256: str) -> dict[str, Any]:
    match = game.get("match")
    if not isinstance(match, dict) or not isinstance(match.get("inputs"), list):
        raise ValueError("game JSON does not contain match.inputs")
    data = reference.get("data")
    if not isinstance(data, dict):
        raise ValueError("reference JSON does not contain data")

    relevant = [row for row in match["inputs"] if isinstance(row, dict) and row.get("type") in INPUT_KINDS]
    rows, duplicate_count = deduplicate(relevant)
    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_kind[row["type"]].append(row)

    unit_events: list[dict[str, Any]] = []
    spending_events: list[dict[str, Any]] = []
    placement_events: list[dict[str, Any]] = []
    unresolved = defaultdict(int)

    # Availability is scoped by player and producing-building instance. For a
    # multi-building selection, each unit is assigned deterministically to the
    # building with the earliest estimated completion slot.
    available_at: dict[tuple[Any, Any], float] = defaultdict(float)
    for queue_index, row in enumerate(by_kind["Queue"]):
        payload = row.get("payload", {})
        time = seconds(row["timestamp"])
        player = row.get("player")
        unit_id = payload.get("unit_id")
        name = payload.get("unit") or row.get("param")
        amount = payload.get("amount")
        entry = reference_entry(data.get("Unit", {}), unit_id)
        if not isinstance(name, str) or not name.strip() or not isinstance(amount, int) or isinstance(amount, bool) or amount <= 0:
            unresolved["Queue_invalid_payload"] += 1
            continue
        name = name.strip()

        if entry is None:
            unresolved["Queue_reference"] += 1
        else:
            train_time = entry.get("TrainTime")
            if isinstance(train_time, (int, float)) and not isinstance(train_time, bool) and math.isfinite(train_time) and train_time >= 0:
                producers: list[Any] = list(object_ids(payload))
                if not producers:
                    producers = [f"unknown:{queue_index}"]
                for _ in range(amount):
                    choices = []
                    for producer in producers:
                        start = max(time, available_at[(player, producer)])
                        choices.append((start + float(train_time), str(producer), producer))
                    completion, _, producer = min(choices)
                    available_at[(player, producer)] = completion
                    unit_events.append({
                        "time": round(completion, 3),
                        "player": player,
                        "unit_id": unit_id,
                        "name": name,
                        "count": 1,
                        "producer_id": producer if isinstance(producer, int) else None,
                    })
            else:
                unresolved["Queue_train_time"] += 1

        cost = normalized_cost(entry.get("Cost") if entry else None, amount)
        if cost:
            spending_events.append({"time": time, "player": player, "kind": "Queue", "name": name, "cost": cost})
        else:
            unresolved["Queue_cost"] += 1

    building_table = data.get("Building", {})
    for kind in ("Build", "Reseed", "Wall"):
        for row in by_kind[kind]:
            payload = row.get("payload", {})
            time = seconds(row["timestamp"])
            player = row.get("player")
            building_id = payload.get("building_id")
            name = payload.get("building") or row.get("param")
            if not isinstance(name, str) or not name.strip():
                unresolved[f"{kind}_invalid_payload"] += 1
                continue
            name = name.strip()

            # The base-data parser can report Siege Workshop as ID 490 even
            # though this pinned reference stores its base cost under ID 49.
            lookup_id = 49 if building_id == 490 else building_id
            entry = reference_entry(building_table, lookup_id)
            multiplier = 1
            if kind == "Wall":
                position = numeric_position(row.get("position"))
                x_end, y_end = payload.get("x_end"), payload.get("y_end")
                if position is not None and isinstance(x_end, (int, float)) and isinstance(y_end, (int, float)):
                    multiplier = int(max(abs(float(x_end) - float(position["x"])), abs(float(y_end) - float(position["y"])))) + 1
                else:
                    unresolved["Wall_segment_count"] += 1
                    multiplier = 0
            cost = normalized_cost(entry.get("Cost") if entry else None, multiplier)
            if cost:
                spending_events.append({"time": time, "player": player, "kind": kind, "name": name, "cost": cost})
            else:
                unresolved[f"{kind}_cost"] += 1

            position = numeric_position(row.get("position"))
            if position is None:
                unresolved[f"{kind}_position"] += 1
                continue
            end_position = None
            if kind == "Wall":
                end_position = numeric_position({"x": payload.get("x_end"), "y": payload.get("y_end")})
            placement = {
                "time": time,
                "player": player,
                "kind": kind,
                "name": name,
                "position": position,
                "footprint": footprint(name, position, end_position),
            }
            if end_position is not None:
                placement["end_position"] = end_position
            placement_events.append(placement)

    for row in by_kind["Research"]:
        payload = row.get("payload", {})
        time = seconds(row["timestamp"])
        player = row.get("player")
        technology_id = payload.get("technology_id")
        name = payload.get("technology") or row.get("param")
        if not isinstance(name, str) or not name.strip():
            unresolved["Research_invalid_payload"] += 1
            continue
        entry, source_table = research_entry(data, technology_id)
        cost = normalized_cost(entry.get("Cost") if entry else None)
        if cost:
            spending_events.append({"time": time, "player": player, "kind": "Research", "name": name.strip(), "cost": cost})
            unresolved[f"Research_resolved_via_{source_table}"] += 0
        else:
            unresolved["Research_cost"] += 1

    event_sort = lambda event: (event["time"], event.get("player", -1), event.get("kind", ""), event.get("name", ""))
    unit_events.sort(key=event_sort)
    spending_events.sort(key=event_sort)
    placement_events.sort(key=event_sort)

    source_recording = game.get("source_recording", {})
    result = {
        "schema": "aoe2-economy-index/v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "game_json": str(DEFAULT_GAME),
            "recording_sha256": source_recording.get("sha256"),
            "reference_project": "SiegeEngineers/aoe2techtree",
            "reference_commit": REFERENCE_COMMIT,
            "reference_url": REFERENCE_URL,
            "reference_loaded_from": reference_source,
            "reference_sha256": reference_sha256,
        },
        "methodology": {
            "unit_completions": "Estimated from deduplicated Queue inputs using payload batch amount, base TrainTime, and sequential producing-building availability. These are production-intent estimates, not confirmed units; queues, cancellations, and civilization production-speed bonuses make them approximate. Starting units are excluded.",
            "spending": "Estimated at input time from pinned base costs for Queue, Build, Reseed, Wall, and Research. Civilization discounts, refunds, free technologies, and other modifiers are not reconstructed, so totals are approximate.",
            "placements": "Observed Build, Reseed, and Wall input positions with best-effort AoE grid footprint estimates. Footprints are occupied grid-tile approximations, not sprite dimensions.",
            "deduplication": "Adjacent parser rows no more than 1 second apart with the same semantic player/entity/producer-or-builder/amount identity are collapsed; placement coordinates and wall endpoints remain part of identity so genuinely distinct placements are retained.",
        },
        "resource_keys": list(RESOURCE_KEYS),
        "counts": {
            "input_rows_considered": len(relevant),
            "deduplicated_input_rows": len(rows),
            "parser_repeat_rows_removed": duplicate_count,
            "unit_completions": len(unit_events),
            "spending": len(spending_events),
            "building_placements": len(placement_events),
        },
        "unresolved": {key: value for key, value in sorted(unresolved.items()) if value},
        "unit_completions": unit_events,
        "spending": spending_events,
        "building_placements": placement_events,
    }
    return result


def validate(index: dict[str, Any]) -> None:
    errors: list[str] = []
    for key in ("unit_completions", "spending", "building_placements"):
        rows = index.get(key)
        if not isinstance(rows, list):
            errors.append(f"{key} is not an array")
            continue
        times = [row.get("time") for row in rows]
        if any(not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0 for value in times):
            errors.append(f"{key} has an invalid time")
        if times != sorted(times):
            errors.append(f"{key} is not sorted by time")

    allowed = set(RESOURCE_KEYS)
    for offset, row in enumerate(index.get("spending", [])):
        cost = row.get("cost")
        if not isinstance(cost, dict) or not cost:
            errors.append(f"spending[{offset}] has empty cost")
            continue
        if not set(cost).issubset(allowed):
            errors.append(f"spending[{offset}] has unexpected resource keys")
        if any(not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0 for value in cost.values()):
            errors.append(f"spending[{offset}] has negative or invalid cost")

    for offset, row in enumerate(index.get("unit_completions", [])):
        if row.get("count") != 1:
            errors.append(f"unit_completions[{offset}] count is not 1")
        if not isinstance(row.get("unit_id"), int) or isinstance(row.get("unit_id"), bool):
            errors.append(f"unit_completions[{offset}] lacks numeric unit_id")

    for offset, row in enumerate(index.get("building_placements", [])):
        footprint_data = row.get("footprint", {})
        if footprint_data.get("tile_width", 0) <= 0 or footprint_data.get("tile_height", 0) <= 0:
            errors.append(f"building_placements[{offset}] has invalid footprint")
        if footprint_data.get("confidence") != "best_effort" or "not_sprite_dimensions" not in footprint_data.get("source", ""):
            errors.append(f"building_placements[{offset}] lacks footprint caveat")

    if index.get("resource_keys") != list(RESOURCE_KEYS):
        errors.append("resource_keys does not have canonical Food/Wood/Gold/Stone order")
    if errors:
        raise ValueError("validation failed:\n- " + "\n- ".join(errors))


def atomic_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(data, indent=2, ensure_ascii=False, separators=(",", ": ")) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
        os.chmod(path, 0o644)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("game_json", nargs="?", type=Path, default=DEFAULT_GAME)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--reference", type=Path, help="Local copy of the pinned tech-tree data.json (avoids network access)")
    args = parser.parse_args()

    game_path = args.game_json.resolve()
    output_path = args.output.resolve()
    raw_reference, reference_source = reference_bytes(args.reference)
    reference_sha256 = hashlib.sha256(raw_reference).hexdigest()
    reference = json.loads(raw_reference)
    game = json.loads(game_path.read_text(encoding="utf-8"))

    index = build_index(game, reference, reference_source, reference_sha256)
    index["source"]["game_json"] = str(game_path)
    validate(index)
    atomic_write(output_path, index)

    # Re-open and revalidate the bytes that reached disk, not just memory.
    written = json.loads(output_path.read_text(encoding="utf-8"))
    validate(written)
    print(f"generator: {Path(__file__).resolve()}")
    print(f"output: {output_path}")
    print(f"unit completions: {len(written['unit_completions'])}")
    print(f"spending events: {len(written['spending'])}")
    print(f"building placements: {len(written['building_placements'])}")
    print(f"parser repeat rows removed: {written['counts']['parser_repeat_rows_removed']}")
    print("validation: sorted arrays; canonical resource keys; nonnegative costs; unit count=1; footprint metadata present")
    print(f"mode: {oct(output_path.stat().st_mode & 0o777)}")


if __name__ == "__main__":
    main()
