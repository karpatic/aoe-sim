# Browser compatibility patches

The bundled upstream-derived pipeline scripts include these narrow portability fixes:

- Replace workstation-specific CLI defaults with neutral relative paths.
- Normalize nullable input types and player names before deterministic summary sorting.
- Treat missing normalized input `type` fields as optional evidence in lifetime inference.
- Use a mixed-type-safe deterministic input sort key and coalesce only incompatible worker states emitted at the same timestamp, preserving last-command-wins state semantics.

These changes do not alter the representative replay's gameplay-derived outputs. They allow parser-supported recordings with nullable or omitted normalized input labels and same-timestamp command transitions to complete the five-stage browser pipeline without embedding private local paths.
