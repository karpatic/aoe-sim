#!/usr/bin/env python3
"""Generate compact JSON Schemas for the domains in one exported AoE II match."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

TYPE_ORDER = {"null": 0, "boolean": 1, "integer": 2, "number": 3, "string": 4, "array": 5, "object": 6}


def primitive_type(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "string"


def infer(values):
    values = list(values)
    types = sorted({primitive_type(value) for value in values}, key=TYPE_ORDER.get)
    schemas = []
    for type_name in types:
        members = [value for value in values if primitive_type(value) == type_name]
        if type_name == "object":
            schemas.append(infer_objects(members))
        elif type_name == "array":
            items = [item for value in members for item in value]
            schema = {"type": "array"}
            schema["items"] = infer(items) if items else {}
            schemas.append(schema)
        else:
            schemas.append({"type": type_name})
    if len(schemas) == 1:
        return schemas[0]
    return {"anyOf": schemas}


def infer_objects(objects):
    values_by_key = defaultdict(list)
    present = defaultdict(int)
    for obj in objects:
        for key, value in obj.items():
            values_by_key[key].append(value)
            present[key] += 1
    schema = {
        "type": "object",
        "properties": {
            key: infer(values_by_key[key])
            for key in sorted(values_by_key)
        },
        "additionalProperties": False,
    }
    required = sorted(key for key, count in present.items() if count == len(objects))
    if required:
        schema["required"] = required
    return schema


def without(value, *keys):
    return {key: item for key, item in value.items() if key not in keys}


def titled(title, values):
    schema = infer(values)
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": title,
        **schema,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("game_json", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    game = json.loads(args.game_json.read_text())
    match = game["match"]
    players = match["players"]

    match_metadata = without(
        match,
        "actions", "chat", "gaia", "inputs", "players", "teams", "uptimes",
    )
    match_metadata["map"] = without(match["map"], "tiles")
    match_metadata["file"] = without(match["file"], "viewlocks")

    targets = [
        ("Source recording", [game["source_recording"]], ["source_recording"]),
        ("Parser provenance", [game["parser"]], ["parser"]),
        ("Viewer summary", [game["summary"]], ["summary"]),
        ("Match metadata", [match_metadata], ["match"]),
        ("Map metadata", [without(match["map"], "tiles")], ["match.map"]),
        ("Player", [without(player, "objects", "timeseries") for player in players], ["match.players[]"]),
        ("Team", match["teams"], ["match.teams[]"]),
        ("Action", match["actions"], ["match.actions[]"]),
        ("Normalized input", match["inputs"], ["match.inputs[]"]),
        ("Chat message", match["chat"], ["match.chat[]"]),
        ("Age-up event", match["uptimes"], ["match.uptimes[]"]),
        ("Viewlock event", match["file"]["viewlocks"], ["match.file.viewlocks[]"]),
        ("Player timeseries row", [row for player in players for row in player["timeseries"]], ["match.players[].timeseries[]"]),
        ("Player starting object", [obj for player in players for obj in player["objects"]], ["match.players[].objects[]"]),
        ("Gaia starting object", match["gaia"], ["match.gaia[]"]),
        ("Map tile", match["map"]["tiles"], ["match.map.tiles[]"]),
    ]
    schemas = {
        "generated_from": args.game_json.name,
        "schemas": [
            {
                "name": title.lower().replace(" ", "_").replace("-", "_"),
                "paths": paths,
                "records_examined": len(values),
                "schema": titled(title, values),
            }
            for title, values, paths in targets
        ],
    }
    args.output.write_text(json.dumps(schemas, indent=2, ensure_ascii=False) + "\n")
    print(f"wrote {args.output} with {len(schemas['schemas'])} schemas")


if __name__ == "__main__":
    main()
