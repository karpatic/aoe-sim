#!/usr/bin/env python3
"""Export the complete aoc-mgz model for one AoE II recording as JSON."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from mgz.model import parse_match, serialize


def sha256_file(path: Path) -> str:
    """Return a streaming SHA-256 digest for *path*."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parser_provenance() -> dict:
    """Read installed parser and reference-data provenance."""
    distribution = importlib.metadata.distribution("mgz")
    direct_url_text = distribution.read_text("direct_url.json")
    direct_url = json.loads(direct_url_text) if direct_url_text else {}
    vcs = direct_url.get("vcs_info", {})
    return {
        "project": "aoc-mgz",
        "distribution": distribution.metadata["Name"],
        "version": distribution.version,
        "source_url": direct_url.get("url"),
        "commit": vcs.get("commit_id"),
        "requested_revision": vcs.get("requested_revision"),
        "aocref_version": importlib.metadata.version("aocref"),
    }


def player_ref(player) -> dict | None:
    """Return a compact stable player reference."""
    if player is None:
        return None
    return {"number": player.number, "name": player.name}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("recording", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--original-source",
        type=Path,
        help="Optional canonical source path when parsing a copied recording.",
    )
    args = parser.parse_args()

    recording = args.recording.resolve(strict=True)
    source_stat = recording.stat()
    with recording.open("rb") as handle:
        match = parse_match(handle)

    action_types = Counter(action.type.name for action in match.actions)
    input_types = Counter(
        str(item.type) if item.type is not None else "<unknown>"
        for item in match.inputs
    )
    actions_by_player = Counter(
        str(action.player.name) if action.player and action.player.name is not None else "<unattributed>"
        for action in match.actions
    )
    inputs_by_player = Counter(
        str(item.player.name) if item.player and item.player.name is not None else "<unattributed>"
        for item in match.inputs
    )

    source = {
        "filename": recording.name,
        "path": str(recording),
        "original_source": (
            str(args.original_source.resolve()) if args.original_source else None
        ),
        "size_bytes": source_stat.st_size,
        "modified_utc": datetime.fromtimestamp(
            source_stat.st_mtime, timezone.utc
        ).isoformat(),
        "sha256": sha256_file(recording),
    }
    counts = {
        "players": len(match.players),
        "teams": len(match.teams),
        "gaia_objects": len(match.gaia),
        "map_tiles": len(match.map.tiles),
        "player_starting_objects": sum(len(player.objects) for player in match.players),
        "timeseries_rows": sum(len(player.timeseries) for player in match.players),
        "actions": len(match.actions),
        "inputs": len(match.inputs),
        "chat_messages": len(match.chat),
        "uptime_events": len(match.uptimes),
        "viewlock_events": len(match.file.viewlocks),
    }
    document = {
        "schema": "aoe2-single-game-dataview/v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "parser": parser_provenance(),
        "source_recording": source,
        "summary": {
            "guid": str(match.guid),
            "played_recorded": match.timestamp.isoformat() if match.timestamp else None,
            "map": {"id": match.map.id, "name": match.map.name},
            "duration_seconds": match.duration.total_seconds(),
            "completed": bool(match.completed),
            "players": [
                {
                    "number": player.number,
                    "name": player.name,
                    "profile_id": player.profile_id,
                    "civilization": player.civilization,
                    "civilization_id": player.civilization_id,
                    "team_numbers": [member.number for member in player.team],
                    "winner": player.winner,
                    "rating_snapshot": player.rate_snapshot,
                    "eapm": player.eapm,
                }
                for player in match.players
            ],
            "perspective_player": player_ref(match.file.perspective),
            "counts": counts,
            "action_types": dict(sorted(action_types.items())),
            "input_types": dict(sorted(input_types.items())),
            "actions_by_player": dict(sorted(actions_by_player.items())),
            "inputs_by_player": dict(sorted(inputs_by_player.items())),
        },
        "collection_paths": {
            "complete_parsed_match_model": "match",
            "actions": "match.actions",
            "normalized_inputs": "match.inputs",
            "chat": "match.chat",
            "age_uptime_events": "match.uptimes",
            "viewlock_events": "match.file.viewlocks",
            "player_timeseries": "match.players[].timeseries",
            "player_starting_objects": "match.players[].objects",
            "gaia_starting_objects": "match.gaia",
            "map_tiles": "match.map.tiles",
        },
        "match": serialize(match),
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(document, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output": str(args.output.resolve()),
                "source": source,
                "parser": document["parser"],
                "players": document["summary"]["players"],
                "map": document["summary"]["map"],
                "duration_seconds": document["summary"]["duration_seconds"],
                "completed": document["summary"]["completed"],
                "counts": counts,
                "action_types": document["summary"]["action_types"],
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
